import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
//import 'package:myapp/page-1/android-large-1.dart';
// import 'package:myapp/page-1/android-large-6.dart';
// import 'package:myapp/page-1/android-large-15.dart';
// import 'package:myapp/page-1/android-large-16.dart';
// import 'package:myapp/page-1/android-large-17.dart';
// import 'package:myapp/page-1/simplificao-booleana.dart';
// import 'package:myapp/page-1/passo-passo-da-converso.dart';
// import 'package:myapp/page-1/conversor-de-bases.dart';
import 'package:myapp/page-1/tela-inicial.dart';
// import 'package:myapp/page-1/android-large-2.dart';
// import 'package:myapp/page-1/android-large-3.dart';
// import 'package:myapp/page-1/android-large-5.dart';
// import 'package:myapp/page-1/android-large-12.dart';
// import 'package:myapp/page-1/android-large-4.dart';
// import 'package:myapp/page-1/frame-13.dart';
// import 'package:myapp/page-1/.dart';
// import 'package:myapp/page-1/-RLT.dart';
// import 'package:myapp/page-1/component-1.dart';
// import 'package:myapp/page-1/component-30.dart';
// import 'package:myapp/page-1/android-large-8.dart';
// import 'package:myapp/page-1/android-large-9.dart';
// import 'package:myapp/page-1/android-large-10.dart';
// import 'package:myapp/page-1/android-large-11.dart';
// import 'package:myapp/page-1/component-21.dart';
// import 'package:myapp/page-1/component-29.dart';
// import 'package:myapp/page-1/android-large-13.dart';
// import 'package:myapp/page-1/android-large-14.dart';
// import 'package:myapp/page-1/android-large-18.dart';
// import 'package:myapp/page-1/android-large-19.dart';
// import 'package:myapp/page-1/android-large-20.dart';
// import 'package:myapp/page-1/android-large-21.dart';
// import 'package:myapp/page-1/android-large-22.dart';
// import 'package:myapp/page-1/android-large-24.dart';
// import 'package:myapp/page-1/android-large-25.dart';
// import 'package:myapp/page-1/android-large-23.dart';
// import 'package:myapp/page-1/android-large-26.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: TelaInicial(),
		),
		),
	);
	}
}
