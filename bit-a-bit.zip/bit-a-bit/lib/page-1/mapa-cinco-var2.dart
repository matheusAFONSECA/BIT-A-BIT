import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/page-1/mapa-cinco-simp.dart';
import 'package:myapp/utils.dart';
import 'mapa-duas-simp.dart';

class MapaCinco2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge11FZ9 (375:974)
        padding: EdgeInsets.fromLTRB(17*fem, 33*fem, 11*fem, 50*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // vccv9V (375:992)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 218*fem, 4*fem),
              child: Text(
                'VCC',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffdfee36),
                ),
              ),
            ),
            Container(
              // autogroupr3nfPYs (CJ3EWfy5zUxcwewurFr3nf)
              margin: EdgeInsets.fromLTRB(33*fem, 0*fem, 36.03*fem, 26.63*fem),
              width: double.infinity,
              height: 118.37*fem,
              child: Stack(
                children: [
                  Positioned(
                    // mapadekarnaughW7h (375:975)
                    left: 23*fem,
                    top: 30.0000305176*fem,
                    child: Align(
                      child: SizedBox(
                        width: 219*fem,
                        height: 33*fem,
                        child: Text(
                          'Mapa de Karnaugh',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ciadM (375:976)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 262.97*fem,
                      height: 118.37*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(40*fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // vector2Uyd (375:977)
                            left: 0*fem,
                            top: 39.6065979004*fem,
                            child: Align(
                              child: SizedBox(
                                width: 112.59*fem,
                                height: 16.44*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-2-ni3.png',
                                  width: 112.59*fem,
                                  height: 16.44*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line32njR (375:978)
                            left: 2.74609375*fem,
                            top: 55.2948303223*fem,
                            child: Align(
                              child: SizedBox(
                                width: 3*fem,
                                height: 22.42*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line30W9d (375:980)
                            left: 2.74609375*fem,
                            top: 77.7066040039*fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line28dEF (375:981)
                            left: 2.74609375*fem,
                            top: 18.6889343262*fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line31MR9 (375:982)
                            left: 2.74609375*fem,
                            top: 16.435333252*fem,
                            child: Align(
                              child: SizedBox(
                                width: 3*fem,
                                height: 22.42*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group1HJo (375:983)
                            left: 217.865234375*fem,
                            top: 75.4529418945*fem,
                            child: Align(
                              child: SizedBox(
                                width: 29.55*fem,
                                height: 22.42*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-1-wUj.png',
                                  width: 29.55*fem,
                                  height: 22.42*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group2b4b (375:987)
                            left: 14.646484375*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 26.8*fem,
                                height: 17.18*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-2-ZmZ.png',
                                  width: 26.8*fem,
                                  height: 17.18*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // gndVfm (375:991)
                            left: 213.4501953125*fem,
                            top: 97.3717651367*fem,
                            child: Align(
                              child: SizedBox(
                                width: 35*fem,
                                height: 21*fem,
                                child: Text(
                                  'GND',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // insiraosvaloresnatabelaPFM (375:993)
              margin: EdgeInsets.fromLTRB(5*fem, 0*fem, 0*fem, 27*fem),
              child: Text(
                'Insira os valores na tabela:',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // eswD (375:1005)
              margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 27*fem),
              child: Text(
                'E',
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // group35noH (382:2098)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 70*fem),
              width: double.infinity,
              height: 288*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouprhpmKHR (CJ3FQZeHnNEuarrfzErhPM)
                    margin: EdgeInsets.fromLTRB(0*fem, 48*fem, 11*fem, 16*fem),
                    width: 38*fem,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // component15dou (375:998)
                          width: 37*fem,
                          height: 35*fem,
                          child: Center(
                            child: Text(
                              'AB',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 25*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // component17KRq (375:1000)
                          width: 37*fem,
                          height: 35*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // abG6B (I375:1000;356:533)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 37*fem,
                                    height: 35*fem,
                                    child: Text(
                                      'AB',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line59AxF (I375:1000;356:537)
                                left: 2*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 16*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // abTwM (375:996)
                          width: double.infinity,
                          child: Text(
                            'AB',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 25*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // component19nTq (375:1002)
                          width: 37*fem,
                          height: 35*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // ab81u (I375:1002;356:535)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 37*fem,
                                    height: 35*fem,
                                    child: Text(
                                      'AB',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line602d5 (I375:1002;356:538)
                                left: 19.9833984375*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 15.03*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupwlx79hh (CJ3FetZkbJ4KdsSnmpwLx7)
                    width: 283*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // component14HZ1 (375:1004)
                          left: 0*fem,
                          top: 34*fem,
                          child: Container(
                            width: 283*fem,
                            height: 254*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // component12Qdd (I375:1004;356:379)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(0*fem, 0.98*fem, 0*fem, 0*fem),
                                    width: 283*fem,
                                    height: 130*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // autogroupbrcb7H9 (CJ3GAxXz2x9kpuh53FbRcB)
                                          width: 321.56*fem,
                                          height: 129.02*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // line44dFV (I375:1004;356:380)
                                                left: 4.564453125*fem,
                                                top: 0*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 129.02*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line468i3 (I375:1004;356:381)
                                                left: 0*fem,
                                                top: 3.3484649658*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 321.56*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line48G3Z (I375:1004;356:382)
                                                left: 0*fem,
                                                top: 64.0151519775*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 278.44*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line45n1u (I375:1004;356:384)
                                                left: 282.9907226562*fem,
                                                top: 0.3282775879*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line5162b (I375:1004;356:385)
                                                left: 213.3842773438*fem,
                                                top: 0.3282775879*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line49bV9 (I375:1004;356:387)
                                                left: 143.77734375*fem,
                                                top: 0.3282775879*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // component29J8f (I375:1004;373:733)
                                                left: 11*fem,
                                                top: 69.0151519775*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 50*fem,
                                                    height: 45*fem,
                                                    child: TextButton(
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Image.asset(
                                                        'assets/page-1/images/component-29.png',
                                                        width: 50*fem,
                                                        height: 45*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // component30zGP (I375:1004;373:847)
                                                left: 80*fem,
                                                top: 70.0151519775*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 50*fem,
                                                    height: 45*fem,
                                                    child: TextButton(
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Image.asset(
                                                        'assets/page-1/images/component-29.png',
                                                        width: 50*fem,
                                                        height: 45*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // component31hRh (I375:1004;373:853)
                                                left: 152*fem,
                                                top: 69.0151519775*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 50*fem,
                                                    height: 45*fem,
                                                    child: TextButton(
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Image.asset(
                                                        'assets/page-1/images/component-29.png',
                                                        width: 50*fem,
                                                        height: 45*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // line47bGB (I375:1004;356:383)
                                          width: 278.44*fem,
                                          height: 5*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component13LjZ (I375:1004;356:412)
                                  left: 0*fem,
                                  top: 124*fem,
                                  child: Container(
                                    width: 283*fem,
                                    height: 130*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // autogroupu9yr49m (CJ3HFvj4ZsFqP2Kixbu9yR)
                                          width: 321.56*fem,
                                          height: 130*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // line44nLf (I375:1004;356:413)
                                                left: 4.564453125*fem,
                                                top: 0.9848480225*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 129.02*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line46JZu (I375:1004;356:414)
                                                left: 0*fem,
                                                top: 4.3333129883*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 321.56*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line48dcB (I375:1004;356:415)
                                                left: 0*fem,
                                                top: 65*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 278.44*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line45Gf9 (I375:1004;356:417)
                                                left: 282.9907226562*fem,
                                                top: 1.3131256104*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line51ntP (I375:1004;356:418)
                                                left: 213.3842773438*fem,
                                                top: 1.3131256104*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line49JLw (I375:1004;356:420)
                                                left: 143.77734375*fem,
                                                top: 1.3131256104*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line572Xq (I375:1004;356:429)
                                                left: 69*fem,
                                                top: 0*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 130*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // component29kTq (I375:1004;373:745)
                                                left: 11*fem,
                                                top: 72*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 50*fem,
                                                    height: 45*fem,
                                                    child: TextButton(
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Image.asset(
                                                        'assets/page-1/images/component-29.png',
                                                        width: 50*fem,
                                                        height: 45*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // component32SrT (I375:1004;373:859)
                                                left: 80*fem,
                                                top: 72*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 50*fem,
                                                    height: 45*fem,
                                                    child: TextButton(
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Image.asset(
                                                        'assets/page-1/images/component-29.png',
                                                        width: 50*fem,
                                                        height: 45*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // component33YuV (I375:1004;373:865)
                                                left: 152*fem,
                                                top: 72*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 50*fem,
                                                    height: 45*fem,
                                                    child: TextButton(
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Image.asset(
                                                        'assets/page-1/images/component-29.png',
                                                        width: 50*fem,
                                                        height: 45*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // line47rQP (I375:1004;356:416)
                                          width: 278.44*fem,
                                          height: 5*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component30NtX (I375:1004;373:799)
                                  left: 221*fem,
                                  top: 9*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 50*fem,
                                      height: 45*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Image.asset(
                                          'assets/page-1/images/component-29.png',
                                          width: 50*fem,
                                          height: 45*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component31URm (I375:1004;373:800)
                                  left: 221*fem,
                                  top: 70*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 50*fem,
                                      height: 45*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Image.asset(
                                          'assets/page-1/images/component-29.png',
                                          width: 50*fem,
                                          height: 45*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component32B5H (I375:1004;373:801)
                                  left: 221*fem,
                                  top: 135*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 50*fem,
                                      height: 45*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Image.asset(
                                          'assets/page-1/images/component-29.png',
                                          width: 50*fem,
                                          height: 45*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component295wM (I375:1004;373:802)
                                  left: 221*fem,
                                  top: 196*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 50*fem,
                                      height: 45*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Image.asset(
                                          'assets/page-1/images/component-29.png',
                                          width: 50*fem,
                                          height: 45*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line56zYX (I375:1004;356:368)
                                  left: 69*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 130*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component20uQb (375:1003)
                          left: 224*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abe7H (I375:1003;356:535)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'CD',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line60wcB (I375:1003;356:538)
                                  left: 19.9833984375*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15.03*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component18sVq (375:1001)
                          left: 83*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abKsd (I375:1001;356:533)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'CD',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line59SBZ (I375:1001;356:537)
                                  left: 2*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 16*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component16M3d (375:999)
                          left: 11*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Center(
                              child: Text(
                                'CD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // cde2j (375:997)
                          left: 155*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 37*fem,
                              height: 35*fem,
                              child: Text(
                                'CD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupbtoh8yV (CJ3EmFP8end5muNWQUbtoH)
              margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 23*fem, 0*fem),
              width: double.infinity,
              height: 65*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group84MM (375:995)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 18*fem, 4*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3fM9 (I375:995;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-2Qw.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // component36nwZ (382:2000)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                    //Botao Simplificar
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => MapaCincoSimp()));
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 147*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            'Simplificar:',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 21*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group5GkF (375:994)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 4*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1mwu (I375:994;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at91515So (I375:994;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-aFh.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}