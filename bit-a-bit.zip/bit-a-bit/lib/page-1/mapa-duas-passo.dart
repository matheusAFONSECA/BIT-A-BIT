import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class MapaDuasPasso extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge12uwm (375:1223)
        padding: EdgeInsets.fromLTRB(33*fem, 39*fem, 31.54*fem, 37*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group291E7 (375:1541)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 348*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(15*fem),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupgldmVuy (CJ2qzKVoHMt3EXApnNgLdm)
                    margin: EdgeInsets.fromLTRB(94.01*fem, 0*fem, 50.36*fem, 4.27*fem),
                    width: double.infinity,
                    height: 58*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogrouplgbqDb5 (CJ2r6EVcRwZWMqHVL1LgBq)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 91.04*fem, 0*fem),
                          width: 30.04*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // bwGB (375:1551)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 30*fem,
                                    height: 58*fem,
                                    child: Text(
                                      'B',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 42*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line43QvT (375:1552)
                                left: 1.0415039062*fem,
                                top: 8.1636657715*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 29*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          // biRM (375:1553)
                          'B',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 42*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xfffcffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupgcfyrXZ (CJ2rDEHxGVErCWgtsiGCfy)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    height: 216.73*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroup9hsdm8j (CJ2rNJsACWJFsWixW29hsd)
                          margin: EdgeInsets.fromLTRB(0*fem, 25.83*fem, 22.91*fem, 33.88*fem),
                          width: 31.02*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogrouplrejUoq (CJ2rTZDR5R4GFXH1fJLrEj)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 47.02*fem),
                                width: double.infinity,
                                height: 55*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // aQSb (375:1548)
                                      left: 0.0187988281*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 31*fem,
                                          height: 55*fem,
                                          child: Text(
                                            'A',
                                            style: SafeGoogleFont (
                                              'Nunito',
                                              fontSize: 40*ffem,
                                              fontWeight: FontWeight.w900,
                                              height: 1.3625*ffem/fem,
                                              color: Color(0xfffcffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // line42767 (375:1550)
                                      left: 0*fem,
                                      top: 6.955657959*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 31*fem,
                                          height: 4*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              color: Color(0xfffcffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // a2D5 (375:1549)
                                margin: EdgeInsets.fromLTRB(0.02*fem, 0*fem, 0*fem, 0*fem),
                                child: Text(
                                  'A',
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 40*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xfffcffff),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroup2n8p8X1 (CJ2raDgyn8GsiYu7Wq2n8P)
                          width: 241.53*fem,
                          height: 216.73*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-2n8p.png',
                            width: 241.53*fem,
                            height: 216.73*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupfrdhekF (CJ2qXR6xd9AYbAqwbdFRdH)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.46*fem, 0*fem),
              height: 92*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group8NgF (375:1245)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 26*fem, 17*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3zSj (I375:1245;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-64F.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group11XxT (343:892)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 0*fem),
                    //Botao Download
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(23*fem, 24*fem, 23*fem, 24*fem),
                        width: 126*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // downloadempdf8ST (I343:892;201:117)
                          child: SizedBox(
                            child: Container(
                              constraints: BoxConstraints (
                                maxWidth: 80*fem,
                              ),
                              child: Text(
                                'Download\nem PDF',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group5du1 (375:1244)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 17*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1vt7 (I375:1244;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151FQb (I375:1244;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-usD.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}