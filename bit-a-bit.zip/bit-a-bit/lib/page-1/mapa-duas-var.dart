import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'mapa-duas-simp.dart';
import 'package:myapp/utils.dart';

class MapaDuas extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge54GX (329:454)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroup9sgfBrw (CJ2nuud5SS5pLCNyLt9SGF)
              left: 50*fem,
              top: 67.9999694824*fem,
              child: Container(
                width: 262.97*fem,
                height: 118.37*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // mapadekarnaugh7Eo (329:455)
                      left: 23*fem,
                      top: 30.0000305176*fem,
                      child: Align(
                        child: SizedBox(
                          width: 219*fem,
                          height: 33*fem,
                          child: Text(
                            'Mapa de Karnaugh',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // cibvf (329:456)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 262.97*fem,
                        height: 118.37*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(40*fem),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // vector278K (329:457)
                              left: 0*fem,
                              top: 39.6065979004*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 112.59*fem,
                                  height: 16.44*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-2-fjM.png',
                                    width: 112.59*fem,
                                    height: 16.44*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line32pHd (329:458)
                              left: 2.7463378906*fem,
                              top: 55.2948303223*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 3*fem,
                                  height: 22.42*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line30wNF (329:460)
                              left: 2.7463378906*fem,
                              top: 77.7066040039*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 257.25*fem,
                                  height: 3*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line28s11 (329:461)
                              left: 2.7463378906*fem,
                              top: 18.6889343262*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 257.25*fem,
                                  height: 3*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line31bBu (329:462)
                              left: 2.7463378906*fem,
                              top: 16.435333252*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 3*fem,
                                  height: 22.42*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // group1Js1 (329:463)
                              left: 217.8654785156*fem,
                              top: 75.4529418945*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 29.55*fem,
                                  height: 22.42*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-1-TgB.png',
                                    width: 29.55*fem,
                                    height: 22.42*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // group2RRq (329:467)
                              left: 14.646484375*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 26.8*fem,
                                  height: 17.18*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-2-rPy.png',
                                    width: 26.8*fem,
                                    height: 17.18*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // gndXjm (329:471)
                              left: 213.4500732422*fem,
                              top: 97.3717651367*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 35*fem,
                                  height: 21*fem,
                                  child: Text(
                                    'GND',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // vccDsV (329:472)
              left: 58*fem,
              top: 43*fem,
              child: Align(
                child: SizedBox(
                  width: 32*fem,
                  height: 21*fem,
                  child: Text(
                    'VCC',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffdfee36),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // insiraosvaloresnatabelaiJT (329:474)
              left: 54.5*fem,
              top: 228*fem,
              child: Align(
                child: SizedBox(
                  width: 258*fem,
                  height: 89*fem,
                  child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 35*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.3625*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                      children: [
                        TextSpan(
                          text: 'Insira os valores na tabela',
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 30*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                        TextSpan(
                          text: ':',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupxj3zjsm (CJ2o9EaCqrX3GFdB3wXJ3Z)
              left: 33*fem,
              top: 688*fem,
              child: Container(
                width: 293*fem,
                height: 58*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group8FbD (343:814)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 180*fem, 0*fem),
                      //Botao menu
                      child: TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.pop(context);
                        },
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xff000000)),
                            color: Color(0xffdfee36),
                            borderRadius: BorderRadius.circular(29*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                          child: Center(
                            // image3fQ3 (I343:814;143:153)
                            child: SizedBox(
                              width: 33*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-3-bGj.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    //Botao voltar
                    TextButton(
                      // group5bYb (343:810)
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1Xh9 (I343:810;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151eWs (I343:810;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-2RD.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group29MRH (329:960)
              left: 50*fem,
              top: 359*fem,
              child: Container(
                width: 232*fem,
                height: 250*fem,
                decoration: BoxDecoration (
                  borderRadius: BorderRadius.circular(15*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // autogrouplnlf56P (CJ2ozi9mQRxXhV7yR9LNLF)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                      width: double.infinity,
                      height: 250*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // autogroupucabCgo (CJ2pGY2jKcrERvixpXUCaB)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11.69*fem, 24.64*fem),
                            width: 31.01*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupwxmz84f (CJ2pPhVTj5kwTS22DKWXMZ)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36.41*fem),
                                  width: double.infinity,
                                  height: 55*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // aSr3 (329:519)
                                        left: 0.0148925781*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 31*fem,
                                            height: 55*fem,
                                            child: Text(
                                              'A',
                                              style: SafeGoogleFont (
                                                'Nunito',
                                                fontSize: 40*ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.3625*ffem/fem,
                                                color: Color(0xfffcffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // line42wXu (329:521)
                                        left: 0*fem,
                                        top: 6.2326812744*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 30.2*fem,
                                            height: 3*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                color: Color(0xfffcffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // aeSK (329:520)
                                  margin: EdgeInsets.fromLTRB(0.01*fem, 0*fem, 0*fem, 0*fem),
                                  child: Text(
                                    'A',
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 40*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xfffcffff),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogrouptebhmG3 (CJ2pXSmZ7kyRdpvs4vTeBH)
                            width: 192.29*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // line37trT (329:514)
                                  left: 93.4204101562*fem,
                                  top: 55.7999992371*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 193.91*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line40QZu (329:515)
                                  left: 0.2260742188*fem,
                                  top: 152.6996459961*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 188.07*fem,
                                      height: 1.39*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/line-40.png',
                                        width: 188.07*fem,
                                        height: 1.39*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line41vo9 (329:516)
                                  left: 0.1413574219*fem,
                                  top: 60.4000015259*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 190.41*fem,
                                      height: 5*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // bF4j (329:522)
                                  left: 31.7370605469*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 30*fem,
                                      height: 58*fem,
                                      child: Text(
                                        'B',
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 42*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line43Z5R (329:523)
                                  left: 32.5617675781*fem,
                                  top: 7.3151130676*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 30.2*fem,
                                      height: 3*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // bGVd (329:524)
                                  left: 127.6142578125*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 30*fem,
                                      height: 58*fem,
                                      child: Text(
                                        'B',
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 42*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xfffcffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component21Aqu (369:368)
                                  left: 19.3000488281*fem,
                                  top: 73*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(10*fem, 13*fem, 10.88*fem, 13.88*fem),
                                      width: 62*fem,
                                      height: 68*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappTKD (I369:368;369:347)
                                        child: SizedBox(
                                          width: 41.12*fem,
                                          height: 41.12*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-sfd.png',
                                            width: 41.12*fem,
                                            height: 41.12*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component21Zd9 (369:374)
                                  left: 113.3000488281*fem,
                                  top: 73*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(10*fem, 13*fem, 10.88*fem, 13.88*fem),
                                      width: 62*fem,
                                      height: 68*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappEjH (I369:374;369:347)
                                        child: SizedBox(
                                          width: 41.12*fem,
                                          height: 41.12*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-LZu.png',
                                            width: 41.12*fem,
                                            height: 41.12*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component21xfH (369:380)
                                  left: 19.3000488281*fem,
                                  top: 170*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(10*fem, 13*fem, 10.88*fem, 13.88*fem),
                                      width: 62*fem,
                                      height: 68*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappSaT (I369:380;369:347)
                                        child: SizedBox(
                                          width: 41.12*fem,
                                          height: 41.12*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-Reo.png',
                                            width: 41.12*fem,
                                            height: 41.12*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component21AFZ (369:386)
                                  left: 113.3000488281*fem,
                                  top: 170*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(10*fem, 13*fem, 10.88*fem, 13.88*fem),
                                      width: 62*fem,
                                      height: 68*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchapp3KM (I369:386;369:347)
                                        child: SizedBox(
                                          width: 41.12*fem,
                                          height: 41.12*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app.png',
                                            width: 41.12*fem,
                                            height: 41.12*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // line39APy (329:517)
                      width: 189.08*fem,
                      height: 5*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff88d498),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // component34WTq (382:1589)
              left: 109*fem,
              top: 684*fem,
              child: Container(
                width: 147*fem,
                height: 65*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff000000)),
                  color: Color(0xffdfee36),
                  borderRadius: BorderRadius.circular(10*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Center(
                  //Botao Simplificar
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => MapaDuasSimp()));
                    },
                    child: Text(
                      'Simplificar:',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 21*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}