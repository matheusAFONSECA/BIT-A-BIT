import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // component1ujV (268:302)
        width: double.infinity,
        height: 206*fem,
        child: Container(
          // androidkeyboardfTm (242:7850)
          width: double.infinity,
          height: double.infinity,
          child: Container(
            // numberkeyboardkk7 (I242:7850;355:8843)
            padding: EdgeInsets.fromLTRB(49*fem, 7*fem, 49*fem, 8*fem),
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration (
              color: Color(0xff292e32),
            ),
            child: Container(
              // group275Gb (I242:7850;355:8845)
              width: double.infinity,
              height: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupsepfQZm (CJ2vNH2yWVgRHJL6YNsEpF)
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // YR5 (I242:7850;355:8900)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectanglehHy (I242:7850;355:8901)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-sTM.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectoroM1 (I242:7850;355:8903)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-EgX.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // X27 (I242:7850;355:8904)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'A',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // ZUb (I242:7850;355:8894)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleWud (I242:7850;355:8895)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-UkX.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vector27H (I242:7850;355:8897)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-YMD.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // M9Z (I242:7850;355:8898)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 19*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'B',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // abce8f (I242:7850;355:8899)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 27*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'ABC',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // KVh (I242:7850;355:8888)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleU7h (I242:7850;355:8889)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-9eP.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorz63 (I242:7850;355:8891)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-W1D.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // 7gT (I242:7850;355:8892)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'C',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // def2YX (I242:7850;355:8893)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 25*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'DEF',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 5*fem,
                  ),
                  Container(
                    // autogroupgfzfuMR (CJ2vfBiU7eZzj7DpwqGFzF)
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // eZu (I242:7850;355:8882)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle1fM (I242:7850;355:8883)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-Mh1.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vector7yH (I242:7850;355:8885)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-TmZ.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // eTR (I242:7850;355:8886)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'D',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // ghiYYo (I242:7850;355:8887)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 24*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'GHI',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // EAj (I242:7850;355:8876)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectanglexsR (I242:7850;355:8877)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-bkb.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorZcK (I242:7850;355:8879)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-zaB.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // JK1 (I242:7850;355:8880)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 18*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'E',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // jklzhd (I242:7850;355:8881)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 25*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'JKL',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // 5j5 (I242:7850;355:8870)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleSZd (I242:7850;355:8871)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-69V.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectoryJf (I242:7850;355:8873)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-n4f.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // i1M (I242:7850;355:8874)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 6*fem,
                                    height: 36*fem,
                                    child: Text(
                                      '‘',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // mnodPD (I242:7850;355:8875)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 32*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'MNO',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 5*fem,
                  ),
                  Container(
                    // autogroupdgpfifZ (CJ2vwLvDAfvRqCc83Pdgpf)
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // 4jR (I242:7850;355:8864)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle1ef (I242:7850;355:8865)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-5GK.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorY8o (I242:7850;355:8867)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-6md.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // TmZ (I242:7850;355:8868)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 11*fem,
                                    height: 36*fem,
                                    child: Text(
                                      '(',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // prqsmXM (I242:7850;355:8869)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 36*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'PRQS',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // FSX (I242:7850;355:8858)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleD8T (I242:7850;355:8859)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-K8s.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorv2s (I242:7850;355:8861)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-CPH.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // qvX (I268:300;268:288)
                                left: 21*fem,
                                top: 5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 18*fem,
                                    height: 36*fem,
                                    child: Text(
                                      '+',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffff9f9),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // L6b (I242:7850;355:8852)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangletP1 (I242:7850;355:8853)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-mz7.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectoroks (I242:7850;355:8855)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-Kro.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // xj8j (I268:301;268:290)
                                left: 20*fem,
                                top: 5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 13*fem,
                                    height: 30*fem,
                                    child: Text(
                                      'x',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 5*fem,
                  ),
                  Container(
                    // autogroupfta3QVm (CJ2wGas9ig37tZxzJ5ftA3)
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupydy18wZ (CJ2wN5hzSxeB3pMXDzYDy1)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // group3V1R (I242:7850;355:8905)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 84*fem,
                                    height: 44*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/group-3-T1y.png',
                                      width: 84*fem,
                                      height: 44*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // a2s (I268:299;268:286)
                                left: 23*fem,
                                top: 4*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 11*fem,
                                    height: 36*fem,
                                    child: Text(
                                      ')',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // Feo (I242:7850;355:8846)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle1dy (I242:7850;355:8847)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-yF5.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorvkw (I242:7850;355:8849)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-2u5.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // fill1ewq (268:285)
                                left: 26*fem,
                                top: 12*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 26*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/fill-1-WMD.png',
                                      width: 26*fem,
                                      height: 20*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        TextButton(
                          // actionbuttonZ3D (I242:7850;355:8910)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 84*fem,
                            height: 44*fem,
                            child: Image.asset(
                              'assets/page-1/images/action-button.png',
                              width: 84*fem,
                              height: 44*fem,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
          );
  }
}