import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'mapa-duas-var.dart';
import 'mapa-tres-var.dart';
import 'mapa-quatro-var.dart';
import 'mapa-cinco-var.dart';

class MapaK extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge3S8o (209:147)
        padding: EdgeInsets.fromLTRB(35 * fem, 38 * fem, 36 * fem, 49 * fem),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // vccjdh (209:172)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 211 * fem, 4 * fem),
              child: Text(
                'VCC',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Nunito',
                  fontSize: 15 * ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625 * ffem / fem,
                  color: Color(0xffdfee36),
                ),
              ),
            ),
            Container(
              // autogroupnea3F6F (CJ2mcCJEVJrHzv7uBHNeA3)
              margin: EdgeInsets.fromLTRB(
                  15 * fem, 0 * fem, 11.03 * fem, 52.63 * fem),
              width: double.infinity,
              height: 118.37 * fem,
              child: Stack(
                children: [
                  Positioned(
                    // mapadekarnaughNgf (209:155)
                    left: 23 * fem,
                    top: 30.0000305176 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 219 * fem,
                        height: 33 * fem,
                        child: Text(
                          'Mapa de Karnaugh',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Nunito',
                            fontSize: 24 * ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625 * ffem / fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // cirrj (209:156)
                    left: 0 * fem,
                    top: 0 * fem,
                    child: Container(
                      width: 262.97 * fem,
                      height: 118.37 * fem,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40 * fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // vector2Zm9 (209:157)
                            left: 0 * fem,
                            top: 39.6065979004 * fem,
                            child: Align(
                              child: SizedBox(
                                width: 112.59 * fem,
                                height: 16.44 * fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-2-5ZH.png',
                                  width: 112.59 * fem,
                                  height: 16.44 * fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line325Dh (209:158)
                            left: 2.7463378906 * fem,
                            top: 55.2948303223 * fem,
                            child: Align(
                              child: SizedBox(
                                width: 3 * fem,
                                height: 22.42 * fem,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line30CZD (209:160)
                            left: 2.7463378906 * fem,
                            top: 77.7066040039 * fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25 * fem,
                                height: 3 * fem,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line288By (209:161)
                            left: 2.7463378906 * fem,
                            top: 18.6889343262 * fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25 * fem,
                                height: 3 * fem,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line31SiT (209:162)
                            left: 2.7463378906 * fem,
                            top: 16.435333252 * fem,
                            child: Align(
                              child: SizedBox(
                                width: 3 * fem,
                                height: 22.42 * fem,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group1aJs (209:163)
                            left: 217.8654785156 * fem,
                            top: 75.4529418945 * fem,
                            child: Align(
                              child: SizedBox(
                                width: 29.55 * fem,
                                height: 22.42 * fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-1-a8X.png',
                                  width: 29.55 * fem,
                                  height: 22.42 * fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group2Hj5 (209:167)
                            left: 14.646484375 * fem,
                            top: 0 * fem,
                            child: Align(
                              child: SizedBox(
                                width: 26.8 * fem,
                                height: 17.18 * fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-2-2UX.png',
                                  width: 26.8 * fem,
                                  height: 17.18 * fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // gndmu9 (209:171)
                            left: 213.4500732422 * fem,
                            top: 97.3717651367 * fem,
                            child: Align(
                              child: SizedBox(
                                width: 35 * fem,
                                height: 21 * fem,
                                child: Text(
                                  'GND',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont(
                                    'Nunito',
                                    fontSize: 15 * ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625 * ffem / fem,
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // selecioneonmerodevariveis4dM (272:307)
              margin: EdgeInsets.fromLTRB(3 * fem, 0 * fem, 0 * fem, 64 * fem),
              constraints: BoxConstraints(
                maxWidth: 274 * fem,
              ),
              child: Text(
                'Selecione o número de variáveis: ',
                textAlign: TextAlign.center,
                style: SafeGoogleFont(
                  'Nunito',
                  fontSize: 25 * ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625 * ffem / fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupdh8k9Pu (CJ2mrBtvAQCygGviGhDh8K)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem, 57 * fem),
              width: double.infinity,
              height: 111 * fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogroupaox3sKu (CJ2mywB1Z5RTrfqZ8JAox3)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 55 * fem, 0 * fem),
                    width: 117 * fem,
                    height: 103 * fem,
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xff000000)),
                      color: Color(0xff88d498),
                      borderRadius: BorderRadius.circular(15 * fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                      ],
                    ),
                    child: Center(
                        child: TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MapaDuas()));
                      },
                      child: Text(
                        '2',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont(
                          'Nunito',
                          fontSize: 40 * ffem,
                          fontWeight: FontWeight.w900,
                          height: 1.3625 * ffem / fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    )),
                  ),
                  Container(
                    // autogrouprzwd4vB (CJ2n3rE9teLYk5GPWsRZwD)
                    width: 117 * fem,
                    height: 103 * fem,
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xff000000)),
                      color: Color(0xff88d498),
                      borderRadius: BorderRadius.circular(15 * fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                      ],
                    ),
                    child: Center(
                      child: TextButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => MapaTres()));
                        },
                        child: Text(
                          '3',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Nunito',
                            fontSize: 40 * ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625 * ffem / fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup2hsdteK (CJ2nB6X5aZrwMzWGqD2HsD)
              margin: EdgeInsets.fromLTRB(0 * fem, 0 * fem, 0 * fem, 55 * fem),
              width: double.infinity,
              height: 103 * fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupf2zu2Ej (CJ2nH6M61cA65iZmJPF2Zu)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 55 * fem, 0 * fem),
                    width: 117 * fem,
                    height: double.infinity,
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xff000000)),
                      color: Color(0xff88d498),
                      borderRadius: BorderRadius.circular(15 * fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                      ],
                    ),
                    child: Center(
                      child: TextButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => MapaQuatro()));
                        },
                        child: Text(
                          '4',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Nunito',
                            fontSize: 40 * ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625 * ffem / fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroup9pfmRnf (CJ2nLWR4eRP5QeKe9h9PfM)
                    width: 117 * fem,
                    height: double.infinity,
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xff000000)),
                      color: Color(0xff88d498),
                      borderRadius: BorderRadius.circular(15 * fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0 * fem, 4 * fem),
                          blurRadius: 2 * fem,
                        ),
                      ],
                    ),
                    child: Center(
                      child: TextButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => MapaCinco()));
                        },
                        child: Text(
                          '5',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Nunito',
                            fontSize: 40 * ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625 * ffem / fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group11fh1 (209:180)
              margin:
                  EdgeInsets.fromLTRB(117 * fem, 0 * fem, 117 * fem, 0 * fem),
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: TextButton.styleFrom(
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 58 * fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse1ySo (I209:180;143:100)
                        left: 0 * fem,
                        top: 0 * fem,
                        child: Align(
                          child: SizedBox(
                            width: 53.47 * fem,
                            height: 54.86 * fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-1.png',
                              width: 53.47 * fem,
                              height: 54.86 * fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // whatsappimage20230726at9151HyH (I209:180;143:101)
                        left: 0 * fem,
                        top: 2.351348877 * fem,
                        child: Align(
                          child: SizedBox(
                            width: 55 * fem,
                            height: 55.65 * fem,
                            child: Image.asset(
                              'assets/page-1/images/whatsappimage2023-07-26at915-1-Hxb.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
