import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'conversor-de-bases.dart';
import 'simplificao-booleana.dart';
import 'mapa-karnaugh.dart';
import 'tabela.dart';

class TelaInicial extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // telainicialXfu (1:3)
        padding: EdgeInsets.fromLTRB(0 * fem, 32 * fem, 0 * fem, 0 * fem),
        width: double.infinity,
        height: 800 * fem,
        decoration: BoxDecoration(
          color: Color(0xff114b5f),
        ),
        child: TextButton(
            // frame1eEj (62:72)
            onPressed: () {},
            style: TextButton.styleFrom(
              padding: EdgeInsets.zero,
            ),
            child: LayoutBuilder(builder:
                (BuildContext context, BoxConstraints viewportConstraints) {
              return SingleChildScrollView(
                child: Container(
                  width: double.infinity,
                  height: 2449 * fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // textosiniciaisxmD (71:74)
                        margin: EdgeInsets.fromLTRB(
                            41 * fem, 0 * fem, 41 * fem, 22 * fem),
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // olsejabemvindoaoUjZ (13:8)
                              margin: EdgeInsets.fromLTRB(
                                  0 * fem, 0 * fem, 0 * fem, 1 * fem),
                              child: Text(
                                'Olá, seja bem-vindo ao',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont(
                                  'Nunito',
                                  fontSize: 25 * ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625 * ffem / fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                            Text(
                              // bitabit9qh (18:11)
                              ' BIT-A-BIT',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont(
                                'Nunito',
                                fontSize: 30 * ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.3625 * ffem / fem,
                                color: Color(0xffdfee36),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroup5fqjtoH (CJ2dTvs9VSZhr4NznA5fQj)
                        padding: EdgeInsets.fromLTRB(
                            33 * fem, 34 * fem, 33 * fem, 45 * fem),
                        width: double.infinity,
                        height: 2350 * fem,
                        decoration: BoxDecoration(
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30 * fem),
                            topRight: Radius.circular(30 * fem),
                          ),
                        ),
                        child: Container(
                          // recursosdoaplicativooQT (62:71)
                          width: double.infinity,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // conversordebaseswWf (62:67)
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 1 * fem, 46 * fem),
                                padding: EdgeInsets.fromLTRB(
                                    0 * fem, 36 * fem, 0 * fem, 32 * fem),
                                width: 293 * fem,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff1a936f)),
                                  color: Color(0xff88d498),
                                  borderRadius: BorderRadius.circular(30 * fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // conversordebasesChV (18:13)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 0 * fem, 12 * fem),
                                      child: Text(
                                        'Conversor de bases',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont(
                                          'Nunito',
                                          fontSize: 28 * ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625 * ffem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupoa797Jf (CJ2ipmwCXzZL8pAc4noA79)
                                      margin: EdgeInsets.fromLTRB(0 * fem,
                                          0 * fem, 0 * fem, 27.76 * fem),
                                      width: double.infinity,
                                      height: 180.24 * fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // image1cWK (24:37)
                                            left: 0 * fem,
                                            top: 0 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 132 * fem,
                                                height: 180 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/image-1.png',
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // image2KvX (27:40)
                                            left: 161 * fem,
                                            top: 0 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 132 * fem,
                                                height: 180 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/image-2.png',
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // 3bd (24:39)
                                            left: 84 * fem,
                                            top: 66 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 14 * fem,
                                                height: 48 * fem,
                                                child: Text(
                                                  '²',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 35 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // wBD (27:44)
                                            left: 230 * fem,
                                            top: 75 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 26 * fem,
                                                height: 29 * fem,
                                                child: Text(
                                                  '10',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 21 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // qGb (24:38)
                                            left: 33 * fem,
                                            top: 51 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 51 * fem,
                                                height: 39 * fem,
                                                child: Text(
                                                  '110',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 28 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // KhZ (27:41)
                                            left: 125.5 * fem,
                                            top: 43 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 42 * fem,
                                                height: 96 * fem,
                                                child: Text(
                                                  '=',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 70 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // Qyu (27:42)
                                            left: 209 * fem,
                                            top: 46 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 21 * fem,
                                                height: 48 * fem,
                                                child: Text(
                                                  '6',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 35 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector3WX9 (102:157)
                                            left: 50.7565460205 * fem,
                                            top: 175.8083496094 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 2.53 * fem,
                                                height: 1.64 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-3.png',
                                                  width: 2.53 * fem,
                                                  height: 1.64 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector41D1 (102:161)
                                            left: 79.7146072388 * fem,
                                            top: 176.440612793 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 0.63 * fem,
                                                height: 1.64 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-4.png',
                                                  width: 0.63 * fem,
                                                  height: 1.64 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector5JC7 (102:163)
                                            left: 76.6679077148 * fem,
                                            top: 177.2473144531 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 0.25 * fem,
                                                height: 0.46 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-5.png',
                                                  width: 0.25 * fem,
                                                  height: 0.46 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector6pAT (102:164)
                                            left: 55.8648376465 * fem,
                                            top: 176.4420471191 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 1.38 * fem,
                                                height: 1.17 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-6.png',
                                                  width: 1.38 * fem,
                                                  height: 1.17 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector7LPh (102:165)
                                            left: 215.2530670166 * fem,
                                            top: 173.4742126465 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 3.16 * fem,
                                                height: 4.28 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-7.png',
                                                  width: 3.16 * fem,
                                                  height: 4.28 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector8TjD (102:170)
                                            left: 217.0998840332 * fem,
                                            top: 176.6485900879 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 0.36 * fem,
                                                height: 0.35 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-8.png',
                                                  width: 0.36 * fem,
                                                  height: 0.35 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector9nFh (102:171)
                                            left: 217.0350799561 * fem,
                                            top: 176.4325866699 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 0.24 * fem,
                                                height: 0.26 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-9.png',
                                                  width: 0.24 * fem,
                                                  height: 0.26 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector107Hy (102:173)
                                            left: 217.0820007324 * fem,
                                            top: 176.6315307617 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 0.28 * fem,
                                                height: 0.37 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-10.png',
                                                  width: 0.28 * fem,
                                                  height: 0.37 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector11qDy (102:174)
                                            left: 237.7209014893 * fem,
                                            top: 176.2498168945 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 1.38 * fem,
                                                height: 2.36 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-11.png',
                                                  width: 1.38 * fem,
                                                  height: 2.36 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector12YPH (102:175)
                                            left: 238.9038085938 * fem,
                                            top: 176.1734008789 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 3 * fem,
                                                height: 1.9 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-12.png',
                                                  width: 3 * fem,
                                                  height: 1.9 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector13FoV (102:176)
                                            left: 233.4037475586 * fem,
                                            top: 179.7850646973 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 1.07 * fem,
                                                height: 0.46 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-13.png',
                                                  width: 1.07 * fem,
                                                  height: 0.46 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector14MrX (102:177)
                                            left: 211.5916595459 * fem,
                                            top: 174.2850036621 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.39 * fem,
                                                height: 5.05 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/vector-14.png',
                                                  width: 5.39 * fem,
                                                  height: 5.05 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // botoentrarUw9 (128:66)
                                      margin: EdgeInsets.fromLTRB(
                                          33 * fem, 0 * fem, 37 * fem, 0 * fem),
                                      child: TextButton(
                                        onPressed: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => Conversor()));
                                        },
                                        style: TextButton.styleFrom(
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          width: double.infinity,
                                          height: 62 * fem,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Color(0xff000000)),
                                            color: Color(0xffdfee36),
                                            borderRadius:
                                                BorderRadius.circular(30 * fem),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                            ],
                                          ),
                                          child: Center(
                                            child: Text(
                                              'Entrar',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont(
                                                'Nunito',
                                                fontSize: 30 * ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.3625 * ffem / fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // simplificaobooleanaSWb (62:68)
                                margin: EdgeInsets.fromLTRB(
                                    1 * fem, 0 * fem, 0 * fem, 45 * fem),
                                padding: EdgeInsets.fromLTRB(
                                    35 * fem, 31 * fem, 35 * fem, 48 * fem),
                                width: 293 * fem,
                                height: 502 * fem,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff1a936f)),
                                  color: Color(0xff88d498),
                                  borderRadius: BorderRadius.circular(30 * fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // simplificaobooleanaVUs (35:6)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 2 * fem, 25 * fem),
                                      constraints: BoxConstraints(
                                        maxWidth: 181 * fem,
                                      ),
                                      child: Text(
                                        'Simplificação Booleana',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont(
                                          'Nunito',
                                          fontSize: 28 * ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625 * ffem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupf9jxNoZ (CJ2iCTeNovKhSp2MZZF9JX)
                                      margin: EdgeInsets.fromLTRB(
                                          4 * fem, 0 * fem, 7 * fem, 0 * fem),
                                      width: double.infinity,
                                      height: 118 * fem,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                            'assets/page-1/images/whatsappimage2023-07-24at903-1-bg.png',
                                          ),
                                        ),
                                      ),
                                      child: Center(
                                        child: Text(
                                          'A.1 = A',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont(
                                            'Nunito',
                                            fontSize: 26 * ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.3625 * ffem / fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupzgpf1rX (CJ2iHnppyHhPREXEeNzgpF)
                                      margin: EdgeInsets.fromLTRB(
                                          4 * fem, 0 * fem, 7 * fem, 23 * fem),
                                      width: double.infinity,
                                      height: 118 * fem,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                            'assets/page-1/images/whatsappimage2023-07-24at903-2-bg.png',
                                          ),
                                        ),
                                      ),
                                      child: Center(
                                        child: Text(
                                          'A.0 = 0',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont(
                                            'Nunito',
                                            fontSize: 26 * ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.3625 * ffem / fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TextButton(
                                      // botoentrart9d (159:49)
                                      onPressed: () {
                                        Navigator.push(context, MaterialPageRoute(builder: (context) => Simplificacao()));
                                      },
                                      style: TextButton.styleFrom(
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        width: double.infinity,
                                        height: 62 * fem,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                              color: Color(0xff000000)),
                                          color: Color(0xffdfee36),
                                          borderRadius:
                                              BorderRadius.circular(30 * fem),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Color(0x3f000000),
                                              offset: Offset(0 * fem, 4 * fem),
                                              blurRadius: 2 * fem,
                                            ),
                                            BoxShadow(
                                              color: Color(0x3f000000),
                                              offset: Offset(0 * fem, 4 * fem),
                                              blurRadius: 2 * fem,
                                            ),
                                            BoxShadow(
                                              color: Color(0x3f000000),
                                              offset: Offset(0 * fem, 4 * fem),
                                              blurRadius: 2 * fem,
                                            ),
                                          ],
                                        ),
                                        child: Center(
                                          child: Text(
                                            'Entrar',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont(
                                              'Nunito',
                                              fontSize: 30 * ffem,
                                              fontWeight: FontWeight.w900,
                                              height: 1.3625 * ffem / fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // mapadekarnaugh5zo (62:69)
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 1 * fem, 45 * fem),
                                padding: EdgeInsets.fromLTRB(
                                    0 * fem, 42 * fem, 0 * fem, 68 * fem),
                                width: 293 * fem,
                                height: 547 * fem,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff1a936f)),
                                  color: Color(0xff88d498),
                                  borderRadius: BorderRadius.circular(30 * fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // mapadekarnaugh9Us (35:15)
                                      margin: EdgeInsets.fromLTRB(
                                          2 * fem, 0 * fem, 0 * fem, 12 * fem),
                                      child: Text(
                                        'Mapa de Karnaugh',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont(
                                          'Nunito',
                                          fontSize: 28 * ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625 * ffem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupodjfEmD (CJ2hR4nM9q2f5or3S1odJF)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 33 * fem, 33 * fem),
                                      width: 260 * fem,
                                      height: 221 * fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // rectangle78bh (39:30)
                                            left: 79 * fem,
                                            top: 145 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 148 * fem,
                                                height: 55 * fem,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    border: Border.all(
                                                        color:
                                                            Color(0xff1a936f)),
                                                    color: Color(0xff88d498),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // whatsappimage20230724at9181qW7 (39:17)
                                            left: 0 * fem,
                                            top: 0 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 260 * fem,
                                                height: 221 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/whatsappimage2023-07-24at918-1.png',
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // ARu (39:29)
                                            left: 96 * fem,
                                            top: 69 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 24 * fem,
                                                height: 55 * fem,
                                                child: Text(
                                                  '0',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 40 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // adqH (39:18)
                                            left: 25 * fem,
                                            top: 70 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 31 * fem,
                                                height: 55 * fem,
                                                child: Text(
                                                  'A',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 40 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // aLUo (39:19)
                                            left: 25 * fem,
                                            top: 158 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 31 * fem,
                                                height: 55 * fem,
                                                child: Text(
                                                  'A',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 40 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // bdTu (39:20)
                                            left: 94 * fem,
                                            top: 1 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 29 * fem,
                                                height: 55 * fem,
                                                child: Text(
                                                  'B',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 40 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // bKLj (39:21)
                                            left: 178 * fem,
                                            top: 0 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 29 * fem,
                                                height: 55 * fem,
                                                child: Text(
                                                  'B\n',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 40 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // p2b (39:24)
                                            left: 96 * fem,
                                            top: 145 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 24 * fem,
                                                height: 55 * fem,
                                                child: Text(
                                                  '1',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 40 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // v5d (39:27)
                                            left: 183 * fem,
                                            top: 69 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 24 * fem,
                                                height: 55 * fem,
                                                child: Text(
                                                  '0',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 40 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // E6K (39:26)
                                            left: 183 * fem,
                                            top: 145 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 24 * fem,
                                                height: 55 * fem,
                                                child: Text(
                                                  '1',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 40 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // autogroup9to5Lf9 (CJ2hgUWLeiqwrBiuDg9To5)
                                      margin: EdgeInsets.fromLTRB(29 * fem,
                                          0 * fem, 28 * fem, 29 * fem),
                                      width: double.infinity,
                                      height: 41 * fem,
                                      child: Center(
                                        child: Text(
                                          'S = AB + AB = A',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont(
                                            'Nunito',
                                            fontSize: 30 * ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.3625 * ffem / fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // botoentrarzjh (209:173)
                                      margin: EdgeInsets.fromLTRB(
                                          35 * fem, 0 * fem, 35 * fem, 0 * fem),
                                      child: TextButton(
                                        onPressed: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => MapaK()));
                                        },
                                        style: TextButton.styleFrom(
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          width: double.infinity,
                                          height: 62 * fem,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Color(0xff000000)),
                                            color: Color(0xffdfee36),
                                            borderRadius:
                                                BorderRadius.circular(30 * fem),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                            ],
                                          ),
                                          child: Center(
                                            child: Text(
                                              'Entrar',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont(
                                                'Nunito',
                                                fontSize: 30 * ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.3625 * ffem / fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // tabeladaverdadeBJP (62:70)
                                margin: EdgeInsets.fromLTRB(
                                    1 * fem, 0 * fem, 0 * fem, 0 * fem),
                                padding: EdgeInsets.fromLTRB(
                                    21.5 * fem, 31 * fem, 23.5 * fem, 42 * fem),
                                width: 293 * fem,
                                height: 697 * fem,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff1a936f)),
                                  color: Color(0xff88d498),
                                  borderRadius: BorderRadius.circular(30 * fem),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // tabeladaverdadeSVD (58:3)
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 0 * fem, 25 * fem),
                                      child: Text(
                                        'Tabela da verdade',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont(
                                          'Nunito',
                                          fontSize: 28 * ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625 * ffem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroup7audKZ1 (CJ2eGA37z81a9C1a997AuD)
                                      margin: EdgeInsets.fromLTRB(35.5 * fem,
                                          0 * fem, 38.5 * fem, 21.99 * fem),
                                      width: double.infinity,
                                      height: 276.01 * fem,
                                      child: Container(
                                        // autogroupg35qqnF (CJ2eoe8fFaZcRFKu6pG35q)
                                        width: 169 * fem,
                                        height: double.infinity,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // awqH (58:39)
                                              left: 20 * fem,
                                              top: 9 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 27 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    'A',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // bdCK (58:40)
                                              left: 77 * fem,
                                              top: 9 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 25 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    'B',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // sX2o (58:41)
                                              left: 127 * fem,
                                              top: 9 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 23 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    'S',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // ET1 (58:42)
                                              left: 23 * fem,
                                              top: 64 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '0\n',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // wMR (58:46)
                                              left: 78 * fem,
                                              top: 63 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '0',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // 3vF (58:43)
                                              left: 23 * fem,
                                              top: 119 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '0',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // Mvw (58:44)
                                              left: 23 * fem,
                                              top: 172 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '1',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // 5M9 (58:45)
                                              left: 23 * fem,
                                              top: 225 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '1',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // aoh (58:47)
                                              left: 77 * fem,
                                              top: 120 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '1',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // 5kT (58:48)
                                              left: 79 * fem,
                                              top: 172 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '0',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // bD1 (58:49)
                                              left: 79 * fem,
                                              top: 225 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '1',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // uDh (58:51)
                                              left: 131 * fem,
                                              top: 63 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '0',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // cdu (58:52)
                                              left: 131 * fem,
                                              top: 119 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '0',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // 8cF (58:53)
                                              left: 131 * fem,
                                              top: 172 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '0',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // 3z7 (58:54)
                                              left: 131 * fem,
                                              top: 225 * fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 21 * fem,
                                                  height: 48 * fem,
                                                  child: Text(
                                                    '1',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 35 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // sabktX (58:55)
                                      margin: EdgeInsets.fromLTRB(
                                          5 * fem, 0 * fem, 0 * fem, 27 * fem),
                                      child: Text(
                                        'S = AB',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont(
                                          'Nunito',
                                          fontSize: 35 * ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625 * ffem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupsycwFqH (CJ2fwGuxsBMXxaCzZaSYCw)
                                      margin: EdgeInsets.fromLTRB(
                                          10 * fem, 0 * fem, 0 * fem, 46 * fem),
                                      height: 79 * fem,
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // autogroupj287ymH (CJ2g8SG2tfo1TtsiGVJ287)
                                            margin: EdgeInsets.fromLTRB(0 * fem,
                                                6 * fem, 4.98 * fem, 2 * fem),
                                            width: 20 * fem,
                                            height: double.infinity,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // au99 (58:63)
                                                  margin: EdgeInsets.fromLTRB(
                                                      0 * fem,
                                                      0 * fem,
                                                      0 * fem,
                                                      1 * fem),
                                                  width: double.infinity,
                                                  child: Text(
                                                    'A',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 25 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  // bcJT (58:64)
                                                  width: double.infinity,
                                                  child: Text(
                                                    'B',
                                                    textAlign: TextAlign.center,
                                                    style: SafeGoogleFont(
                                                      'Nunito',
                                                      fontSize: 25 * ffem,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      height:
                                                          1.3625 * ffem / fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // autogroupwkpokQf (CJ2gES63Ki6ABcwCjfWkpo)
                                            margin: EdgeInsets.fromLTRB(0 * fem,
                                                0 * fem, 6 * fem, 0 * fem),
                                            width: 169.02 * fem,
                                            height: 79 * fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-wkpo.png',
                                              width: 169.02 * fem,
                                              height: 79 * fem,
                                            ),
                                          ),
                                          Container(
                                            // abEKq (58:62)
                                            margin: EdgeInsets.fromLTRB(0 * fem,
                                                2 * fem, 0 * fem, 0 * fem),
                                            child: Text(
                                              'AB',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont(
                                                'Nunito',
                                                fontSize: 25 * ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.3625 * ffem / fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // botoentrarkJB (209:207)
                                      margin: EdgeInsets.fromLTRB(
                                          16 * fem, 0 * fem, 0 * fem, 0 * fem),
                                      child: TextButton(
                                        onPressed: () {
                                          Navigator.push(context, MaterialPageRoute(builder: (context) => Tabela()));
                                        },
                                        style: TextButton.styleFrom(
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Container(
                                          width: 223 * fem,
                                          height: 62 * fem,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Color(0xff000000)),
                                            color: Color(0xffdfee36),
                                            borderRadius:
                                                BorderRadius.circular(30 * fem),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                              BoxShadow(
                                                color: Color(0x3f000000),
                                                offset:
                                                    Offset(0 * fem, 4 * fem),
                                                blurRadius: 2 * fem,
                                              ),
                                            ],
                                          ),
                                          child: Center(
                                            child: Text(
                                              'Entrar',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont(
                                                'Nunito',
                                                fontSize: 30 * ffem,
                                                fontWeight: FontWeight.w900,
                                                height: 1.3625 * ffem / fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            })),
      ),
    );
  }
}
