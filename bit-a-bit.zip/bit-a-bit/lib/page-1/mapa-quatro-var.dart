import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/page-1/mapa-quatro-simp.dart';
import 'package:myapp/utils.dart';
import 'mapa-duas-simp.dart';

class MapaQuatro extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge9m1y (356:451)
        padding: EdgeInsets.fromLTRB(16*fem, 33*fem, 12*fem, 51*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogrouppjddqXd (CJ352cSHx24SdCKHCvpJDd)
              margin: EdgeInsets.fromLTRB(34*fem, 0*fem, 35.03*fem, 26.63*fem),
              width: double.infinity,
              height: 138.37*fem,
              child: Stack(
                children: [
                  Positioned(
                    // mapadekarnaughMVy (356:452)
                    left: 23*fem,
                    top: 50*fem,
                    child: Align(
                      child: SizedBox(
                        width: 219*fem,
                        height: 33*fem,
                        child: Text(
                          'Mapa de Karnaugh',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // cipeT (356:453)
                    left: 0*fem,
                    top: 19.9999694824*fem,
                    child: Container(
                      width: 262.97*fem,
                      height: 118.37*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(40*fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // vector2izj (356:454)
                            left: 0*fem,
                            top: 39.6065979004*fem,
                            child: Align(
                              child: SizedBox(
                                width: 112.59*fem,
                                height: 16.44*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-2-wd1.png',
                                  width: 112.59*fem,
                                  height: 16.44*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line32pXy (356:455)
                            left: 2.74609375*fem,
                            top: 55.2948303223*fem,
                            child: Align(
                              child: SizedBox(
                                width: 3*fem,
                                height: 22.42*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line30jew (356:457)
                            left: 2.74609375*fem,
                            top: 77.7066040039*fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line283vX (356:458)
                            left: 2.74609375*fem,
                            top: 18.6889343262*fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line31kK9 (356:459)
                            left: 2.74609375*fem,
                            top: 16.435333252*fem,
                            child: Align(
                              child: SizedBox(
                                width: 3*fem,
                                height: 22.42*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group1fS7 (356:460)
                            left: 217.865234375*fem,
                            top: 75.4529418945*fem,
                            child: Align(
                              child: SizedBox(
                                width: 29.55*fem,
                                height: 22.42*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-1-ubD.png',
                                  width: 29.55*fem,
                                  height: 22.42*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group2aJB (356:464)
                            left: 14.646484375*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 26.8*fem,
                                height: 17.18*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-2-SUX.png',
                                  width: 26.8*fem,
                                  height: 17.18*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // gnd61d (356:468)
                            left: 213.4501953125*fem,
                            top: 97.3717651367*fem,
                            child: Align(
                              child: SizedBox(
                                width: 35*fem,
                                height: 21*fem,
                                child: Text(
                                  'GND',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // vccahV (356:469)
                    left: 8*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 32*fem,
                        height: 21*fem,
                        child: Text(
                          'VCC',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 15*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffdfee36),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // insiraosvaloresnatabela58T (356:470)
              margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 0*fem, 26*fem),
              constraints: BoxConstraints (
                maxWidth: 213*fem,
              ),
              child: Text(
                'Insira os valores na tabela:',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 27*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // group31m1H (382:1806)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 98*fem),
              width: double.infinity,
              height: 288*fem,
              child: Stack(
                children: [
                  Positioned(
                    // component14Gij (356:430)
                    left: 49*fem,
                    top: 34*fem,
                    child: Container(
                      width: 283*fem,
                      height: 254*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // component12PYT (356:379)
                            left: 0*fem,
                            top: 0*fem,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(0*fem, 0.98*fem, 0*fem, 0*fem),
                              width: 283*fem,
                              height: 130*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // autogroupbzpxV5h (CJ36p4TvPxAHXxMVnibzpX)
                                    width: 321.56*fem,
                                    height: 129.02*fem,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // line44QiT (356:380)
                                          left: 4.564453125*fem,
                                          top: 0*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 129.02*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line46KKd (356:381)
                                          left: 0*fem,
                                          top: 3.3484649658*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 321.56*fem,
                                              height: 5*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line48qYs (356:382)
                                          left: 0*fem,
                                          top: 64.0151519775*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 278.44*fem,
                                              height: 5*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line45MXD (356:384)
                                          left: 282.9907226562*fem,
                                          top: 0.3282775879*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 128.69*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line515TD (356:385)
                                          left: 213.3842773438*fem,
                                          top: 0.3282775879*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 128.69*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line49nsR (356:387)
                                          left: 143.77734375*fem,
                                          top: 0.3282775879*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 128.69*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // component29hjV (373:733)
                                          left: 11*fem,
                                          top: 69.0151519775*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 50*fem,
                                              height: 45*fem,
                                              child: TextButton(
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Image.asset(
                                                  'assets/page-1/images/component-29.png',
                                                  width: 50*fem,
                                                  height: 45*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // component30nW3 (373:847)
                                          left: 80*fem,
                                          top: 70.0151519775*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 50*fem,
                                              height: 45*fem,
                                              child: TextButton(
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Image.asset(
                                                  'assets/page-1/images/component-29.png',
                                                  width: 50*fem,
                                                  height: 45*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // component31UNs (373:853)
                                          left: 152*fem,
                                          top: 69.0151519775*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 50*fem,
                                              height: 45*fem,
                                              child: TextButton(
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Image.asset(
                                                  'assets/page-1/images/component-29.png',
                                                  width: 50*fem,
                                                  height: 45*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // line47NDM (356:383)
                                    width: 278.44*fem,
                                    height: 5*fem,
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // component13uyy (356:412)
                            left: 0*fem,
                            top: 124*fem,
                            child: Container(
                              width: 283*fem,
                              height: 130*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // autogroupavawEWT (CJ37xwi9GSBSyUQz6eAVAw)
                                    width: 321.56*fem,
                                    height: 130*fem,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // line44UQo (356:413)
                                          left: 4.564453125*fem,
                                          top: 0.9848480225*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 129.02*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line46ayd (356:414)
                                          left: 0*fem,
                                          top: 4.3333129883*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 321.56*fem,
                                              height: 5*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line487Tm (356:415)
                                          left: 0*fem,
                                          top: 65*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 278.44*fem,
                                              height: 5*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line45EYP (356:417)
                                          left: 282.9907226562*fem,
                                          top: 1.3131256104*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 128.69*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line51mYK (356:418)
                                          left: 213.3842773438*fem,
                                          top: 1.3131256104*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 128.69*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line49gvB (356:420)
                                          left: 143.77734375*fem,
                                          top: 1.3131256104*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 128.69*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // line57DQK (356:429)
                                          left: 69*fem,
                                          top: 0*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 5*fem,
                                              height: 130*fem,
                                              child: Container(
                                                decoration: BoxDecoration (
                                                  color: Color(0xff88d498),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // component29YhV (373:745)
                                          left: 11*fem,
                                          top: 72*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 50*fem,
                                              height: 45*fem,
                                              child: TextButton(
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Image.asset(
                                                  'assets/page-1/images/component-29.png',
                                                  width: 50*fem,
                                                  height: 45*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // component32Fbu (373:859)
                                          left: 80*fem,
                                          top: 72*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 50*fem,
                                              height: 45*fem,
                                              child: TextButton(
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Image.asset(
                                                  'assets/page-1/images/component-29.png',
                                                  width: 50*fem,
                                                  height: 45*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // component33m4T (373:865)
                                          left: 152*fem,
                                          top: 72*fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 50*fem,
                                              height: 45*fem,
                                              child: TextButton(
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Image.asset(
                                                  'assets/page-1/images/component-29.png',
                                                  width: 50*fem,
                                                  height: 45*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // line47Txs (356:416)
                                    width: 278.44*fem,
                                    height: 5*fem,
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // component30pYX (373:799)
                            left: 221*fem,
                            top: 9*fem,
                            child: Align(
                              child: SizedBox(
                                width: 50*fem,
                                height: 45*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/page-1/images/component-29.png',
                                    width: 50*fem,
                                    height: 45*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // component3183R (373:800)
                            left: 221*fem,
                            top: 70*fem,
                            child: Align(
                              child: SizedBox(
                                width: 50*fem,
                                height: 45*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/page-1/images/component-29.png',
                                    width: 50*fem,
                                    height: 45*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // component32pB9 (373:801)
                            left: 221*fem,
                            top: 135*fem,
                            child: Align(
                              child: SizedBox(
                                width: 50*fem,
                                height: 45*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/page-1/images/component-29.png',
                                    width: 50*fem,
                                    height: 45*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // component29uCb (373:802)
                            left: 221*fem,
                            top: 196*fem,
                            child: Align(
                              child: SizedBox(
                                width: 50*fem,
                                height: 45*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/page-1/images/component-29.png',
                                    width: 50*fem,
                                    height: 45*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line56cMu (356:368)
                            left: 69*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 5*fem,
                                height: 130*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff88d498),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // component20LHu (384:1008)
                    left: 273*fem,
                    top: 0*fem,
                    child: Container(
                      width: 37*fem,
                      height: 35*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // absYj (384:1009)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 37*fem,
                                height: 35*fem,
                                child: Text(
                                  'CD',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line60Anj (384:1010)
                            left: 17.5*fem,
                            top: 3*fem,
                            child: Align(
                              child: SizedBox(
                                width: 18*fem,
                                height: 4*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // component19VKD (356:548)
                    left: 0*fem,
                    top: 237*fem,
                    child: Container(
                      width: 37*fem,
                      height: 34*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // abpMV (356:535)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 37*fem,
                                height: 35*fem,
                                child: Text(
                                  'AB',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line60v9d (356:538)
                            left: 19.9833984375*fem,
                            top: 3*fem,
                            child: Align(
                              child: SizedBox(
                                width: 15.03*fem,
                                height: 4*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // component18bWf (356:544)
                    left: 132*fem,
                    top: 0*fem,
                    child: Container(
                      width: 37*fem,
                      height: 35*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // abX9R (I356:544;356:533)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 37*fem,
                                height: 35*fem,
                                child: Text(
                                  'CD',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line59puD (I356:544;356:537)
                            left: 2*fem,
                            top: 3*fem,
                            child: Align(
                              child: SizedBox(
                                width: 16*fem,
                                height: 4*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // component17wU3 (356:543)
                    left: 0*fem,
                    top: 111*fem,
                    child: Container(
                      width: 37*fem,
                      height: 34*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // abGmD (356:533)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 37*fem,
                                height: 35*fem,
                                child: Text(
                                  'AB',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line59NpF (356:537)
                            left: 2*fem,
                            top: 3*fem,
                            child: Align(
                              child: SizedBox(
                                width: 16*fem,
                                height: 4*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // component16hrX (356:540)
                    left: 60*fem,
                    top: 0*fem,
                    child: Container(
                      width: 37*fem,
                      height: 35*fem,
                      child: Center(
                        child: Text(
                          'CD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // component15PUT (356:539)
                    left: 0*fem,
                    top: 45*fem,
                    child: Container(
                      width: 37*fem,
                      height: 37*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // ab8S3 (356:532)
                            left: 0*fem,
                            top: 3*fem,
                            child: Align(
                              child: SizedBox(
                                width: 37*fem,
                                height: 35*fem,
                                child: Text(
                                  'AB',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line58EEB (356:536)
                            left: 2*fem,
                            top: 3*fem,
                            child: Align(
                              child: SizedBox(
                                width: 33*fem,
                                height: 4*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // cdLo1 (356:547)
                    left: 204*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 37*fem,
                        height: 35*fem,
                        child: Text(
                          'CD',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // abrFZ (356:534)
                    left: 0*fem,
                    top: 174*fem,
                    child: Align(
                      child: SizedBox(
                        width: 37*fem,
                        height: 35*fem,
                        child: Text(
                          'AB',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupufhhA1M (CJ35SBbMFtAdY2q7TuuFHH)
              margin: EdgeInsets.fromLTRB(17*fem, 0*fem, 22*fem, 0*fem),
              width: double.infinity,
              height: 65*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group8H5y (356:473)
                    margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 18*fem, 3*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3t5m (I356:473;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-La3.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // component35QZu (382:1593)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                    //Botao Simplificar
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => MapaQuatroSimp()));
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 147*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            'Simplificar:',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 21*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group5knB (356:472)
                    margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 3*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1Fyq (I356:472;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151B6o (I356:472;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-DM9.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}