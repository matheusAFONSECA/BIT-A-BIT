import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'expressao-simplificada.dart';

class Simplificacao extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // simplificaobooleanabtT (159:20)
        padding: EdgeInsets.fromLTRB(29*fem, 33*fem, 29*fem, 50*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // vccVU3 (159:48)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 206*fem, 1*fem),
              child: Text(
                'VCC',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffdfee36),
                ),
              ),
            ),
            Container(
              // autogroupjutrQ5D (CJ2aXbbJB2ShVnHHtSjUTR)
              margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 16.03*fem, 37.63*fem),
              width: double.infinity,
              height: 118.37*fem,
              child: Stack(
                children: [
                  Positioned(
                    // simplificaobooleanavJT (159:21)
                    left: 16.5*fem,
                    top: 30.0000305176*fem,
                    child: Align(
                      child: SizedBox(
                        width: 226*fem,
                        height: 28*fem,
                        child: Text(
                          'Simplificação Booleana',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ci1ao (159:31)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 262.97*fem,
                      height: 118.37*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(40*fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // vector27dq (159:32)
                            left: 0*fem,
                            top: 39.6065979004*fem,
                            child: Align(
                              child: SizedBox(
                                width: 112.59*fem,
                                height: 16.44*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-2-MDq.png',
                                  width: 112.59*fem,
                                  height: 16.44*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line32cKh (159:33)
                            left: 2.7462158203*fem,
                            top: 55.2948303223*fem,
                            child: Align(
                              child: SizedBox(
                                width: 3*fem,
                                height: 22.42*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line30v5V (159:35)
                            left: 2.7462158203*fem,
                            top: 77.7066040039*fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line28qCT (159:36)
                            left: 2.7462158203*fem,
                            top: 18.6889343262*fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line31ZPM (159:37)
                            left: 2.7462158203*fem,
                            top: 16.435333252*fem,
                            child: Align(
                              child: SizedBox(
                                width: 3*fem,
                                height: 22.42*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group15Mh (159:38)
                            left: 217.8654785156*fem,
                            top: 75.4529418945*fem,
                            child: Align(
                              child: SizedBox(
                                width: 29.55*fem,
                                height: 22.42*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-1-Pv7.png',
                                  width: 29.55*fem,
                                  height: 22.42*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group2nG7 (159:42)
                            left: 14.646484375*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 26.8*fem,
                                height: 17.18*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-2-dDy.png',
                                  width: 26.8*fem,
                                  height: 17.18*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // gndVAX (159:46)
                            left: 213.4501953125*fem,
                            top: 97.3717651367*fem,
                            child: Align(
                              child: SizedBox(
                                width: 35*fem,
                                height: 21*fem,
                                child: Text(
                                  'GND',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // entrecomaexpressoquedesejasimp (242:8416)
              margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 44*fem),
              constraints: BoxConstraints (
                maxWidth: 266*fem,
              ),
              child: Text(
                'Entre com a expressão que deseja simplificar:',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // rectangle22SV5 (268:294)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 58*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  child: Center(
                    // rectangle22ZZh (242:8417)
                    child: SizedBox(
                      width: double.infinity,
                      height: 317*fem,
                      child: Container(
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(30*fem),
                          border: Border.all(color: Color(0xff1a936f)),
                          color: Color(0xff88d498),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupjm1rVTM (CJ2ajg5WKZegXeM6kLjM1R)
              margin: EdgeInsets.fromLTRB(30*fem, 0*fem, 22*fem, 0*fem),
              width: double.infinity,
              height: 65*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // group11cns (392:1092)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 48*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => ExpressaoSimplificada()));
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 147*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            'Simplificar:',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 21*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group5D1y (159:59)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: 58*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1Wmm (I159:59;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151Rtj (I159:59;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-LL7.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}