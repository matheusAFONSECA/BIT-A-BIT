import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/page-1/mapa-tres-simp.dart';
import 'package:myapp/utils.dart';
import 'mapa-duas-simp.dart';

class MapaTres extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge8Kbd (347:895)
        padding: EdgeInsets.fromLTRB(20*fem, 38*fem, 20*fem, 51*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // vccxPh (347:913)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 212*fem, 4*fem),
              child: Text(
                'VCC',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffdfee36),
                ),
              ),
            ),
            Container(
              // autogroupdh2fSJs (CJ2zpjSf4QhfNNXz9mDh2F)
              margin: EdgeInsets.fromLTRB(30*fem, 0*fem, 27.03*fem, 46.63*fem),
              width: double.infinity,
              height: 118.37*fem,
              child: Stack(
                children: [
                  Positioned(
                    // mapadekarnaughjom (347:896)
                    left: 23*fem,
                    top: 30.0000305176*fem,
                    child: Align(
                      child: SizedBox(
                        width: 219*fem,
                        height: 33*fem,
                        child: Text(
                          'Mapa de Karnaugh',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ci1mH (347:897)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 262.97*fem,
                      height: 118.37*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(40*fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // vector285D (347:898)
                            left: 0*fem,
                            top: 39.6065979004*fem,
                            child: Align(
                              child: SizedBox(
                                width: 112.59*fem,
                                height: 16.44*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-2-xA3.png',
                                  width: 112.59*fem,
                                  height: 16.44*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line321eo (347:899)
                            left: 2.7463378906*fem,
                            top: 55.2948303223*fem,
                            child: Align(
                              child: SizedBox(
                                width: 3*fem,
                                height: 22.42*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line30HcK (347:901)
                            left: 2.7463378906*fem,
                            top: 77.7066040039*fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line28yk3 (347:902)
                            left: 2.7463378906*fem,
                            top: 18.6889343262*fem,
                            child: Align(
                              child: SizedBox(
                                width: 257.25*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line31tMD (347:903)
                            left: 2.7463378906*fem,
                            top: 16.435333252*fem,
                            child: Align(
                              child: SizedBox(
                                width: 3*fem,
                                height: 22.42*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group1oj5 (347:904)
                            left: 217.865234375*fem,
                            top: 75.4529571533*fem,
                            child: Align(
                              child: SizedBox(
                                width: 29.55*fem,
                                height: 22.42*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-1-oY3.png',
                                  width: 29.55*fem,
                                  height: 22.42*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group2Jvj (347:908)
                            left: 14.646484375*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 26.8*fem,
                                height: 17.18*fem,
                                child: Image.asset(
                                  'assets/page-1/images/group-2-FBD.png',
                                  width: 26.8*fem,
                                  height: 17.18*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // gndosV (347:912)
                            left: 213.4501953125*fem,
                            top: 97.3717651367*fem,
                            child: Align(
                              child: SizedBox(
                                width: 35*fem,
                                height: 21*fem,
                                child: Text(
                                  'GND',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffdfee36),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // insiraosvaloresnatabelahCB (347:914)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 45*fem),
              constraints: BoxConstraints (
                maxWidth: 281*fem,
              ),
              child: Text(
                'Insira os valores na tabela:',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 30*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // component12Np7 (351:358)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 79*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 250*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupgon75Td (CJ31csnSGdXr56DjbCgoN7)
                    margin: EdgeInsets.fromLTRB(55*fem, 0*fem, 20*fem, 7.5*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // component8PjD (351:354)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 25*fem, 0*fem),
                          width: 42*fem,
                          height: 41*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // bcK75 (I351:354;347:966)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 42*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'BC',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line55cM5 (I351:354;347:973)
                                left: 0*fem,
                                top: 4*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 42*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // component97Yj (351:355)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 28*fem, 0*fem),
                          width: 42*fem,
                          height: 41*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // bcEdM (I351:355;347:967)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 42*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'BC',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line53ja7 (I351:355;347:971)
                                left: 0*fem,
                                top: 4*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // bc3Ku (I351:352;347:968)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 1*fem),
                          child: Text(
                            'BC',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 30*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Container(
                          // component10AQX (351:356)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                          width: 42*fem,
                          height: 41*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // bcJFq (I351:356;347:969)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 42*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'BC',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line54D7u (347:972)
                                left: 22*fem,
                                top: 5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20.02*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupduj97j5 (CJ31pHd69VpNMeiw4kDUj9)
                    width: double.infinity,
                    height: 201.5*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // component11rRm (351:353)
                          margin: EdgeInsets.fromLTRB(0*fem, 13.5*fem, 9*fem, 39*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // autogroupizhvnaK (CJ31x7jNpdeY8TabqtizhV)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 26*fem),
                                padding: EdgeInsets.fromLTRB(4*fem, 18*fem, 0*fem, 23*fem),
                                width: 27*fem,
                                height: 82*fem,
                                child: Container(
                                  // autogroupl9apJYf (CJ322XmgrxFiaLgPmjL9aP)
                                  width: double.infinity,
                                  height: double.infinity,
                                  child: Center(
                                    child: Text(
                                      'A',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // aPa7 (I351:353;347:965)
                                'A',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 30*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // component7LET (351:357)
                          width: 287.99*fem,
                          height: double.infinity,
                          child: Container(
                            // autogrouptbkuHQb (CJ32c1otwRa96JgYtTtbKu)
                            width: double.infinity,
                            height: 196.5*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // line44auV (I351:357;347:954)
                                  left: 4.564453125*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 196.5*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line46hjD (I351:357;347:957)
                                  left: 4.564453125*fem,
                                  top: 5.1000003815*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 278.44*fem,
                                      height: 5*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line48DxT (I351:357;347:959)
                                  left: 0*fem,
                                  top: 97.5*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 278.44*fem,
                                      height: 5*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line51LnB (I351:357;347:962)
                                  left: 213.3842773438*fem,
                                  top: 0.5*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 196*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line494y5 (I351:357;347:960)
                                  left: 143.77734375*fem,
                                  top: 0.5*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 196*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line49awR (351:444)
                                  left: 77*fem,
                                  top: 3.5*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 191*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component22iGw (369:404)
                                  left: 78*fem,
                                  top: 20.5*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(9.03*fem, 11.85*fem, 9.83*fem, 12.66*fem),
                                      width: 56*fem,
                                      height: 62*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappPts (I369:404;369:347)
                                        child: SizedBox(
                                          width: 37.14*fem,
                                          height: 37.49*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-AWT.png',
                                            width: 37.14*fem,
                                            height: 37.49*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component23WCo (369:410)
                                  left: 148*fem,
                                  top: 21.5*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(9.03*fem, 11.85*fem, 9.83*fem, 12.66*fem),
                                      width: 56*fem,
                                      height: 62*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappnRD (I369:410;369:347)
                                        child: SizedBox(
                                          width: 37.14*fem,
                                          height: 37.49*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-as1.png',
                                            width: 37.14*fem,
                                            height: 37.49*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component246Ru (369:416)
                                  left: 218*fem,
                                  top: 21.5*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(9.03*fem, 11.85*fem, 9.83*fem, 12.66*fem),
                                      width: 56*fem,
                                      height: 62*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappaM5 (I369:416;369:347)
                                        child: SizedBox(
                                          width: 37.14*fem,
                                          height: 37.49*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-e63.png',
                                            width: 37.14*fem,
                                            height: 37.49*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component256aK (369:422)
                                  left: 10*fem,
                                  top: 115.5*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(9.03*fem, 11.85*fem, 9.83*fem, 12.66*fem),
                                      width: 56*fem,
                                      height: 62*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappz9u (I369:422;369:347)
                                        child: SizedBox(
                                          width: 37.14*fem,
                                          height: 37.49*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-Pm9.png',
                                            width: 37.14*fem,
                                            height: 37.49*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component267VR (369:428)
                                  left: 78*fem,
                                  top: 115.5*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(9.03*fem, 11.85*fem, 9.83*fem, 12.66*fem),
                                      width: 56*fem,
                                      height: 62*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappBkB (I369:428;369:347)
                                        child: SizedBox(
                                          width: 37.14*fem,
                                          height: 37.49*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-Uij.png',
                                            width: 37.14*fem,
                                            height: 37.49*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component27tuV (369:434)
                                  left: 148*fem,
                                  top: 115.5*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(9.03*fem, 11.85*fem, 9.83*fem, 12.66*fem),
                                      width: 56*fem,
                                      height: 62*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappnEB (I369:434;369:347)
                                        child: SizedBox(
                                          width: 37.14*fem,
                                          height: 37.49*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-9m1.png',
                                            width: 37.14*fem,
                                            height: 37.49*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component287GT (369:440)
                                  left: 218*fem,
                                  top: 115.5*fem,
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(9.03*fem, 11.85*fem, 9.83*fem, 12.66*fem),
                                      width: 56*fem,
                                      height: 62*fem,
                                      decoration: BoxDecoration (
                                        color: Color(0xff114b5f),
                                      ),
                                      child: Center(
                                        // icontouchappBXD (I369:440;369:347)
                                        child: SizedBox(
                                          width: 37.14*fem,
                                          height: 37.49*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-touch-app-W1u.png',
                                            width: 37.14*fem,
                                            height: 37.49*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupjlb1tgX (CJ3154N7sLX5RP86wMJLb1)
              margin: EdgeInsets.fromLTRB(13*fem, 0*fem, 14*fem, 0*fem),
              width: double.infinity,
              height: 65*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group8bqq (347:919)
                    margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 18*fem, 3*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3bjM (I347:919;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-deo.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // component34X7D (382:1590)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                    //Botao Simplificar
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => MapaTresSimp()));
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 147*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            'Simplificar:',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 21*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group5G6j (347:918)
                    margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 3*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1xVM (I347:918;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151s6X (I347:918;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-96P.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}