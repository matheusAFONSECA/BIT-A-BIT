import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/page-1/mapa-cinco-passo.dart';
import 'package:myapp/utils.dart';

class MapaCincoSimp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge177SF (382:2003)
        padding: EdgeInsets.fromLTRB(33*fem, 59*fem, 34*fem, 37*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // expressosimplificada2p7 (382:2004)
              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 577*fem),
              child: Text(
                'Expressão Simplificada:',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupaufuvuV (CJ2aAC3JF6LG1gLwdcAuFu)
              width: double.infinity,
              height: 92*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group8fs5 (382:2006)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 26*fem, 17*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3uFd (I382:2006;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-aoy.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group10dhR (382:2005)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 0*fem),
                    //Botao Passo-a-passo
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => MapaCincoPasso()));
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(21*fem, 13*fem, 21*fem, 13*fem),
                        width: 126*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // resoluopassoapassorKH (I382:2005;128:77)
                          child: SizedBox(
                            child: Container(
                              constraints: BoxConstraints (
                                maxWidth: 84*fem,
                              ),
                              child: Text(
                                'Resolução \npasso a passo',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group5MWw (382:2007)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 17*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1fGj (I382:2007;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151xWj (I382:2007;143:101)
                              left: 0*fem,
                              top: 2.3513183594*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-duy.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}