import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'conversao-passo.dart';

class Conversor extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // conversordebasesS5d (71:75)
        padding: EdgeInsets.fromLTRB(0 * fem, 54 * fem, 0 * fem, 0 * fem),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupc2vbYeT (CJ2bZpMxLoFFUGigLqc2vB)
              width: double.infinity,
              height: 406 * fem,
              child: Stack(
                children: [
                  Positioned(
                    // group4tiK (118:3)
                    left: 0 * fem,
                    top: 20.9999694824 * fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(
                          19 * fem, 0 * fem, 9.5 * fem, 37 * fem),
                      width: 360 * fem,
                      height: 385 * fem,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(40 * fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // cin31 (118:11)
                            margin: EdgeInsets.fromLTRB(
                                8 * fem, 0 * fem, 17.5 * fem, 21.63 * fem),
                            width: double.infinity,
                            height: 118.37 * fem,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(40 * fem),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // vector25no (118:12)
                                  left: 31.049987793 * fem,
                                  top: 39.6065979004 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 104.55 * fem,
                                      height: 16.44 * fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-2.png',
                                        width: 104.55 * fem,
                                        height: 16.44 * fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line32bFM (118:13)
                                  left: 33.6000061035 * fem,
                                  top: 55.2948303223 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 3 * fem,
                                      height: 22.42 * fem,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xffdfee36),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line29i55 (118:14)
                                  left: 272.450012207 * fem,
                                  top: 18.6889648438 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 3 * fem,
                                      height: 59.32 * fem,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xffdfee36),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line30dC3 (118:15)
                                  left: 33.6000061035 * fem,
                                  top: 77.7066040039 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 238.87 * fem,
                                      height: 3 * fem,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xffdfee36),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line28YZu (118:16)
                                  left: 33.6000061035 * fem,
                                  top: 18.6889343262 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 238.87 * fem,
                                      height: 3 * fem,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xffdfee36),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line31sMH (118:17)
                                  left: 33.6000061035 * fem,
                                  top: 16.435333252 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 3 * fem,
                                      height: 22.42 * fem,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xffdfee36),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // group1zgo (118:18)
                                  left: 233.3499755859 * fem,
                                  top: 75.4529571533 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 27.65 * fem,
                                      height: 22.42 * fem,
                                      child: Image.asset(
                                        'assets/page-1/images/group-1-H3V.png',
                                        width: 27.65 * fem,
                                        height: 22.42 * fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // group26E3 (118:22)
                                  left: 44.6499938965 * fem,
                                  top: 0 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 25.1 * fem,
                                      height: 17.18 * fem,
                                      child: Image.asset(
                                        'assets/page-1/images/group-2-bAw.png',
                                        width: 25.1 * fem,
                                        height: 17.18 * fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // gnd167 (118:26)
                                  left: 228 * fem,
                                  top: 97.3717651367 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 35 * fem,
                                      height: 21 * fem,
                                      child: Text(
                                        'GND',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont(
                                          'Nunito',
                                          fontSize: 15 * ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625 * ffem / fem,
                                          color: Color(0xffdfee36),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // conversordebasesUVV (118:27)
                                  left: 49.5 * fem,
                                  top: 32.0000305176 * fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 207 * fem,
                                      height: 30 * fem,
                                      child: Text(
                                        'Conversor de bases',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont(
                                          'Nunito',
                                          fontSize: 22 * ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625 * ffem / fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupuyddM3V (CJ2bi4dDSE9qD9JUjhuYdd)
                            margin: EdgeInsets.fromLTRB(
                                0 * fem, 0 * fem, 0 * fem, 16 * fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // insiraabasedonmerogbZ (118:9)
                                  margin: EdgeInsets.fromLTRB(
                                      0 * fem, 0 * fem, 31.5 * fem, 1 * fem),
                                  constraints: BoxConstraints(
                                    maxWidth: 134 * fem,
                                  ),
                                  child: Text(
                                    'Insira a base do número:',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont(
                                      'Nunito',
                                      fontSize: 21 * ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625 * ffem / fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // insiraparaqualbaseconverterAmd (118:6)
                                  margin: EdgeInsets.fromLTRB(
                                      0 * fem, 1 * fem, 0 * fem, 0 * fem),
                                  constraints: BoxConstraints(
                                    maxWidth: 166 * fem,
                                  ),
                                  child: Text(
                                    'Insira para qual base converter:',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont(
                                      'Nunito',
                                      fontSize: 21 * ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625 * ffem / fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupf69mG3y (CJ2boPofbbXXBZoMpXf69M)
                            margin: EdgeInsets.fromLTRB(
                                15 * fem, 0 * fem, 35.5 * fem, 33 * fem),
                            width: double.infinity,
                            height: 63 * fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // rectangle29PeP (315:687)
                                  margin: EdgeInsets.fromLTRB(
                                      0 * fem, 0 * fem, 81 * fem, 0 * fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom(
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 100 * fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Color(0xff000000)),
                                        color: Color(0xff88d498),
                                        borderRadius:
                                            BorderRadius.circular(10 * fem),
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // selecioneUA3 (I315:687;310:224)
                                            left: 13 * fem,
                                            top: 9 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 74 * fem,
                                                height: 21 * fem,
                                                child: Text(
                                                  'Selecione:',
                                                  style: SafeGoogleFont(
                                                    'Nunito',
                                                    fontSize: 15 * ffem,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1.3625 * ffem / fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // iconkeyboardarrowdownx5D (I315:687;310:228)
                                            left: 30 * fem,
                                            top: 24 * fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 34.49 * fem,
                                                height: 34.49 * fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/icon-keyboard-arrow-down.png',
                                                  width: 34.49 * fem,
                                                  height: 34.49 * fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                TextButton(
                                  // rectangle29SWB (315:693)
                                  onPressed: () {},
                                  style: TextButton.styleFrom(
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 100 * fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration(
                                      border:
                                          Border.all(color: Color(0xff000000)),
                                      color: Color(0xff88d498),
                                      borderRadius:
                                          BorderRadius.circular(10 * fem),
                                    ),
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          // selecioneZao (I315:693;310:224)
                                          left: 13 * fem,
                                          top: 9 * fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 74 * fem,
                                              height: 21 * fem,
                                              child: Text(
                                                'Selecione:',
                                                style: SafeGoogleFont(
                                                  'Nunito',
                                                  fontSize: 15 * ffem,
                                                  fontWeight: FontWeight.w900,
                                                  height: 1.3625 * ffem / fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          // iconkeyboardarrowdownfdq (I315:693;310:228)
                                          left: 30 * fem,
                                          top: 24 * fem,
                                          child: Align(
                                            child: SizedBox(
                                              width: 34.49 * fem,
                                              height: 34.49 * fem,
                                              child: Image.asset(
                                                'assets/page-1/images/icon-keyboard-arrow-down-zDV.png',
                                                width: 34.49 * fem,
                                                height: 34.49 * fem,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // insiraonmerokvB (118:10)
                            margin: EdgeInsets.fromLTRB(
                                0 * fem, 0 * fem, 9.5 * fem, 0 * fem),
                            child: Text(
                              'Insira o número:\n',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont(
                                'Nunito',
                                fontSize: 27 * ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.3625 * ffem / fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // vccsV1 (118:28)
                    left: 64 * fem,
                    top: 0 * fem,
                    child: Align(
                      child: SizedBox(
                        width: 32 * fem,
                        height: 21 * fem,
                        child: Text(
                          'VCC',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont(
                            'Nunito',
                            fontSize: 15 * ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625 * ffem / fem,
                            color: Color(0xffdfee36),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupzvqhMf5 (CJ2cSD5f2RTFS3cZs2ZVqh)
              padding:
                  EdgeInsets.fromLTRB(27 * fem, 0 * fem, 16 * fem, 35 * fem),
              width: double.infinity,
              height: 340 * fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // rectangle1255H (264:436)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 0 * fem, 35 * fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        child: Center(
                          // rectangle12anj (118:8)
                          child: SizedBox(
                            width: double.infinity,
                            height: 55 * fem,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20 * fem),
                                border: Border.all(color: Color(0xff000000)),
                                color: Color(0xff88d498),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // resultadoJij (118:29)
                    margin: EdgeInsets.fromLTRB(
                        5 * fem, 0 * fem, 0 * fem, 16 * fem),
                    child: Text(
                      'Resultado:',
                      style: SafeGoogleFont(
                        'Nunito',
                        fontSize: 27 * ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.3625 * ffem / fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // group6DKu (264:284)
                    margin: EdgeInsets.fromLTRB(
                        0 * fem, 0 * fem, 0 * fem, 30 * fem),
                    width: double.infinity,
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xff000000)),
                      borderRadius: BorderRadius.circular(20 * fem),
                    ),
                    child: Center(
                      // rectangle15LvK (264:285)
                      child: SizedBox(
                        width: double.infinity,
                        height: 55 * fem,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20 * fem),
                            border: Border.all(color: Color(0xff000000)),
                            color: Color(0xff88d498),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupnnwhrtf (CJ2cHJAqfKdCwsUA5onnwH)
                    margin: EdgeInsets.fromLTRB(
                        55 * fem, 0 * fem, 56 * fem, 0 * fem),
                    width: double.infinity,
                    height: 92 * fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group7BR9 (128:91)
                          margin: EdgeInsets.fromLTRB(
                              0 * fem, 0 * fem, 25 * fem, 0 * fem),
                          child: TextButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ConversaoPasso()));
                            },
                            style: TextButton.styleFrom(
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(
                                  21 * fem, 13 * fem, 21 * fem, 13 * fem),
                              width: 126 * fem,
                              height: double.infinity,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xff000000)),
                                color: Color(0xffdfee36),
                                borderRadius: BorderRadius.circular(10 * fem),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x3f000000),
                                    offset: Offset(0 * fem, 4 * fem),
                                    blurRadius: 2 * fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x3f000000),
                                    offset: Offset(0 * fem, 4 * fem),
                                    blurRadius: 2 * fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x3f000000),
                                    offset: Offset(0 * fem, 4 * fem),
                                    blurRadius: 2 * fem,
                                  ),
                                ],
                              ),
                              child: Center(
                                // resoluopassoapassoC5M (I128:91;128:77)
                                child: SizedBox(
                                  child: Container(
                                    constraints: BoxConstraints(
                                      maxWidth: 84 * fem,
                                    ),
                                    child: Text(
                                      'Resolução \npasso a passo',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont(
                                        'Nunito',
                                        fontSize: 16 * ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625 * ffem / fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // group13Vq9 (375:1582)
                          margin: EdgeInsets.fromLTRB(
                              0 * fem, 17 * fem, 0 * fem, 17 * fem),
                          //Botao voltar
                          child: TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            style: TextButton.styleFrom(
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 55 * fem,
                              height: double.infinity,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // ellipse1pMd (I375:1582;143:100)
                                    left: 0 * fem,
                                    top: 0 * fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 53.47 * fem,
                                        height: 54.86 * fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ellipse-1.png',
                                          width: 53.47 * fem,
                                          height: 54.86 * fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // whatsappimage20230726at9151LKy (I375:1582;143:101)
                                    left: 0 * fem,
                                    top: 2.351348877 * fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 55 * fem,
                                        height: 55.65 * fem,
                                        child: Image.asset(
                                          'assets/page-1/images/whatsappimage2023-07-26at915-1-nJB.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
