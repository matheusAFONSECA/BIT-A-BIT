import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'tabela-duas-passo.dart';

class TabelaDuas extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge20Bhq (392:1130)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Stack(
          children: [
            Positioned(
              // component38iSs (392:1128)
              left: 31*fem,
              top: 85*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(3*fem, 2*fem, 0*fem, 0*fem),
                width: 298*fem,
                height: 433*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupi5bdCsq (CJ3cXTTJxhds2E9gByi5BD)
                      width: 299*fem,
                      height: 431*fem,
                      child: Container(
                        // autogroupxhip9o5 (CJ3coSzfSokvwVeKSSxhiP)
                        width: 294*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // line63hJo (392:1114)
                              left: 3.1127929688*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 4*fem,
                                  height: 431*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line69PxK (392:1120)
                              left: 201.779296875*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 4*fem,
                                  height: 431*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line68iUo (392:1119)
                              left: 102.4462890625*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 4*fem,
                                  height: 431*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line64FDq (392:1115)
                              left: 0*fem,
                              top: 4.0559387207*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 294*fem,
                                  height: 4*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line72a1D (392:1123)
                              left: 0*fem,
                              top: 258.4055786133*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 294*fem,
                                  height: 4*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line73JT1 (392:1127)
                              left: 0*fem,
                              top: 349.2447509766*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 294*fem,
                                  height: 4*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // aRnX (392:1124)
                              left: 41.0744628906*fem,
                              top: 24*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 23*fem,
                                  height: 41*fem,
                                  child: Text(
                                    'A',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xfff5f5f5),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // bWZ5 (392:1125)
                              left: 140.8103027344*fem,
                              top: 25*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 22*fem,
                                  height: 41*fem,
                                  child: Text(
                                    'B',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xfff5f5f5),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line71o2P (392:1122)
                              left: 0*fem,
                              top: 170.5944061279*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 294*fem,
                                  height: 4*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line70JE3 (392:1121)
                              left: 0*fem,
                              top: 85.8111877441*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 294*fem,
                                  height: 4*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xff88d498),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // sQXy (392:1126)
                              left: 238.2819824219*fem,
                              top: 24*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 20*fem,
                                  height: 41*fem,
                                  child: Text(
                                    'S',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xfff5f5f5),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      // line65JtF (392:1116)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                      width: 294*fem,
                      height: 4*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff88d498),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group313L3 (392:1132)
              left: 33*fem,
              top: 667*fem,
              //Botao Menu
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                  width: 58*fem,
                  height: 58*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff000000)),
                    color: Color(0xffdfee36),
                    borderRadius: BorderRadius.circular(29*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    // image3s4B (I392:1132;143:153)
                    child: SizedBox(
                      width: 33*fem,
                      height: 32*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-3-pPZ.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group42QK1 (392:1135)
              left: 271*fem,
              top: 667*fem,
              //Botao Voltar
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 55*fem,
                  height: 58*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse1X8j (I392:1135;143:100)
                        left: 0*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 53.47*fem,
                            height: 54.86*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-1.png',
                              width: 53.47*fem,
                              height: 54.86*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // whatsappimage20230726at9151qQK (I392:1135;143:101)
                        left: 0*fem,
                        top: 2.351348877*fem,
                        child: Align(
                          child: SizedBox(
                            width: 55*fem,
                            height: 55.65*fem,
                            child: Image.asset(
                              'assets/page-1/images/whatsappimage2023-07-26at915-1-qsD.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // group118uD (392:1139)
              left: 117*fem,
              top: 650*fem,
              //Botao Passo-a-passo
              child: TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => TabDuasPasso()));
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(21*fem, 13*fem, 21*fem, 13*fem),
                  width: 126*fem,
                  height: 92*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff000000)),
                    color: Color(0xffdfee36),
                    borderRadius: BorderRadius.circular(10*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    // resoluopassoapassoYxw (I392:1139;128:77)
                    child: SizedBox(
                      child: Container(
                        constraints: BoxConstraints (
                          maxWidth: 84*fem,
                        ),
                        child: Text(
                          'Resolução \npasso a passo',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}