import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class TabTresPasso extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge23rjR (397:1145)
        padding: EdgeInsets.fromLTRB(23*fem, 42*fem, 24*fem, 30*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // passoapassodatabeladaverdadede (397:1156)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 567*fem),
              constraints: BoxConstraints (
                maxWidth: 313*fem,
              ),
              child: Text(
                'Passo a passo da tabela da verdade de 3 variáveis:',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupx143N5V (CJ3nNRYwELxPGK3hYsx143)
              margin: EdgeInsets.fromLTRB(10*fem, 0*fem, 10*fem, 0*fem),
              width: double.infinity,
              height: 92*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group44gby (397:1146)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 26*fem, 17*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3Unj (I397:1146;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-6ko.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group462JT (397:1148)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 0*fem),
                    //Botao Download
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(23*fem, 24*fem, 23*fem, 24*fem),
                        width: 126*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // downloadempdfqFu (I397:1148;201:117)
                          child: SizedBox(
                            child: Container(
                              constraints: BoxConstraints (
                                maxWidth: 80*fem,
                              ),
                              child: Text(
                                'Download\nem PDF',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group458ko (397:1147)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 17*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1Rzo (I397:1147;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151YpX (I397:1147;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-MZh.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}