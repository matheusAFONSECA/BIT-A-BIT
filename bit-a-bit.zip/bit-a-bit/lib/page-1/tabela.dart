import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'tabela-duas.dart';
import 'tabela-tres.dart';
import 'tabela-quatro.dart';

class Tabela extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge4ueo (209:184)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroup7bk3dKu (CJ2sBsLFEXb3fFUkdi7bk3)
              left: 50*fem,
              top: 33*fem,
              child: Container(
                width: 262.97*fem,
                height: 138.37*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // ciM11 (209:185)
                      left: 0*fem,
                      top: 19.9999694824*fem,
                      child: Container(
                        width: 262.97*fem,
                        height: 118.37*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(40*fem),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // vector23eX (209:186)
                              left: 0*fem,
                              top: 39.6065979004*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 112.59*fem,
                                  height: 16.44*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-2-GTR.png',
                                    width: 112.59*fem,
                                    height: 16.44*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line32ZMy (209:187)
                              left: 2.74609375*fem,
                              top: 55.2948303223*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 3*fem,
                                  height: 22.42*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line30ffu (209:189)
                              left: 2.74609375*fem,
                              top: 77.7066040039*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 257.25*fem,
                                  height: 3*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line28zTH (209:190)
                              left: 2.74609375*fem,
                              top: 18.6889343262*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 257.25*fem,
                                  height: 3*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line31XCK (209:191)
                              left: 2.74609375*fem,
                              top: 16.435333252*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 3*fem,
                                  height: 22.42*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // group12es (209:192)
                              left: 217.865234375*fem,
                              top: 75.4529418945*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 29.55*fem,
                                  height: 22.42*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-1.png',
                                    width: 29.55*fem,
                                    height: 22.42*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // group2j3V (209:196)
                              left: 14.646484375*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 26.8*fem,
                                  height: 17.18*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-2.png',
                                    width: 26.8*fem,
                                    height: 17.18*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // gndDjM (209:200)
                              left: 213.4501953125*fem,
                              top: 97.3717651367*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 35*fem,
                                  height: 21*fem,
                                  child: Text(
                                    'GND',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // tabeladaverdadetKh (209:202)
                              left: 29*fem,
                              top: 31.0000305176*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 213*fem,
                                  height: 33*fem,
                                  child: Text(
                                    'Tabela da verdade',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // vcckco (209:201)
                      left: 9*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 32*fem,
                          height: 21*fem,
                          child: Text(
                            'VCC',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffdfee36),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group12pcf (209:203)
              left: 152*fem,
              top: 701*fem,
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 55*fem,
                  height: 58*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse1iT9 (I209:203;143:100)
                        left: 0*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 53.47*fem,
                            height: 54.86*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-1.png',
                              width: 53.47*fem,
                              height: 54.86*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // whatsappimage20230726at9151da7 (I209:203;143:101)
                        left: 0*fem,
                        top: 2.351348877*fem,
                        child: Align(
                          child: SizedBox(
                            width: 55*fem,
                            height: 55.65*fem,
                            child: Image.asset(
                              'assets/page-1/images/whatsappimage2023-07-26at915-1-EB1.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // entrecomaexpressoquedesejaobte (390:1010)
              left: 48*fem,
              top: 209*fem,
              child: Align(
                child: SizedBox(
                  width: 260*fem,
                  height: 82*fem,
                  child: Text(
                    'Entre com a expressão que\ndeseja obter a\ntabela da verdade:',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // selecioneonmerodevariveisnrK (392:1095)
              left: 25.5*fem,
              top: 547*fem,
              child: Align(
                child: SizedBox(
                  width: 321*fem,
                  height: 28*fem,
                  child: Text(
                    'Selecione o número de variáveis: ',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group38UDM (392:1111)
              left: 61*fem,
              top: 598*fem,
              //Botao Tabela Duas Variaveis
              child: TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => TabelaDuas()));
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 70*fem,
                  height: 70*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff000000)),
                    color: Color(0xffdfee36),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Center(
                    child: Text(
                      '2',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 35*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group41Wfq (392:1109)
              left: 143*fem,
              top: 598*fem,
              //Botao Tabela Tres Variaveis
              child: TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => TabelaTres()));
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 70*fem,
                  height: 70*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff000000)),
                    color: Color(0xffdfee36),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Center(
                    child: Text(
                      '3',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 35*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group40joV (392:1108)
              left: 225*fem,
              top: 598*fem,
              //Botao Tabela Quatro Variaveis
              child: TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => TabelaQuatro()));
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 70*fem,
                  height: 70*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff000000)),
                    color: Color(0xffdfee36),
                    borderRadius: BorderRadius.circular(10*fem),
                  ),
                  child: Center(
                    child: Text(
                      '4',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Nunito',
                        fontSize: 35*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.3625*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle45mVH (421:1224)
              left: 34*fem,
              top: 321*fem,
              //Botao Voltar
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 292*fem,
                  height: 196*fem,
                  child: Center(
                    // rectangle45sYK (I421:1224;390:1009)
                    child: SizedBox(
                      width: double.infinity,
                      height: 196*fem,
                      child: Container(
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(15*fem),
                          border: Border.all(color: Color(0xff1a936f)),
                          color: Color(0xff88d498),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}