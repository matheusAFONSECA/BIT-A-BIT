import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'mapa-cinco-var2.dart';

class MapaCinco extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge10Utw (375:788)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogrouprmjoyKu (CJ398pvhYRaoXwpPV6RmJo)
              left: 50*fem,
              top: 67.9999694824*fem,
              child: Container(
                width: 262.97*fem,
                height: 118.37*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // mapadekarnaughH5h (375:789)
                      left: 23*fem,
                      top: 30.0000305176*fem,
                      child: Align(
                        child: SizedBox(
                          width: 219*fem,
                          height: 33*fem,
                          child: Text(
                            'Mapa de Karnaugh',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 24*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // ciiwh (375:790)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 262.97*fem,
                        height: 118.37*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(40*fem),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // vector2d35 (375:791)
                              left: 0*fem,
                              top: 39.6065979004*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 112.59*fem,
                                  height: 16.44*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-2-Yud.png',
                                    width: 112.59*fem,
                                    height: 16.44*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line32Kgb (375:792)
                              left: 2.74609375*fem,
                              top: 55.2948303223*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 3*fem,
                                  height: 22.42*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line302b1 (375:794)
                              left: 2.74609375*fem,
                              top: 77.7066040039*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 257.25*fem,
                                  height: 3*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line2899q (375:795)
                              left: 2.74609375*fem,
                              top: 18.6889343262*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 257.25*fem,
                                  height: 3*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // line31GVM (375:796)
                              left: 2.74609375*fem,
                              top: 16.435333252*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 3*fem,
                                  height: 22.42*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // group1PZy (375:797)
                              left: 217.865234375*fem,
                              top: 75.4529418945*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 29.55*fem,
                                  height: 22.42*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-1-Ui3.png',
                                    width: 29.55*fem,
                                    height: 22.42*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // group2JB9 (375:801)
                              left: 14.646484375*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 26.8*fem,
                                  height: 17.18*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-2-kGf.png',
                                    width: 26.8*fem,
                                    height: 17.18*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // gndQjy (375:805)
                              left: 213.4501953125*fem,
                              top: 97.3717651367*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 35*fem,
                                  height: 21*fem,
                                  child: Text(
                                    'GND',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Nunito',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.3625*ffem/fem,
                                      color: Color(0xffdfee36),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // vccgxP (375:806)
              left: 58*fem,
              top: 43*fem,
              child: Align(
                child: SizedBox(
                  width: 32*fem,
                  height: 21*fem,
                  child: Text(
                    'VCC',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffdfee36),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // insiraosvaloresnatabelankX (375:807)
              left: 23*fem,
              top: 213*fem,
              child: Align(
                child: SizedBox(
                  width: 325*fem,
                  height: 35*fem,
                  child: Text(
                    'Insira os valores na tabela:',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 25*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroup3x8pUtF (CJ39UuBaw1rKXSdWyE3x8P)
              left: 33*fem,
              top: 688*fem,
              child: Container(
                width: 293*fem,
                height: 58*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // group8D59 (375:810)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 180*fem, 0*fem),
                      //Botao Menu
                      child: TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.pop(context);
                        },
                        style: TextButton.styleFrom (
                          padding: EdgeInsets.zero,
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            border: Border.all(color: Color(0xff000000)),
                            color: Color(0xffdfee36),
                            borderRadius: BorderRadius.circular(29*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                          child: Center(
                            // image3DDZ (I375:810;143:153)
                            child: SizedBox(
                              width: 33*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-3-SKZ.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    TextButton(
                      // group54EB (375:809)
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1nfy (I375:809;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151Wby (I375:809;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-vDm.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group34RD9 (382:1999)
              left: 17*fem,
              top: 341*fem,
              child: Container(
                width: 332*fem,
                height: 288*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupoyf1jzX (CJ3A9da3tPvkRRBjFEoYF1)
                      margin: EdgeInsets.fromLTRB(0*fem, 48*fem, 12*fem, 16*fem),
                      width: 37*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // component15rZM (375:813)
                            width: double.infinity,
                            height: 35*fem,
                            child: Center(
                              child: Text(
                                'AB',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 28*fem,
                          ),
                          Container(
                            // component17w51 (375:815)
                            width: double.infinity,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abUqd (I375:815;356:533)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'AB',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line59z3H (I375:815;356:537)
                                  left: 2*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 16*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 28*fem,
                          ),
                          Text(
                            // abUj9 (375:811)
                            'AB',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 25*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                          SizedBox(
                            height: 28*fem,
                          ),
                          Container(
                            // component19Q71 (375:817)
                            width: double.infinity,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abkwZ (I375:817;356:535)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'AB',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line60Tb5 (I375:817;356:538)
                                  left: 19.9833984375*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15.03*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupzpfdB1H (CJ3AQCz6YhbDFfcKoTZPFd)
                      width: 283*fem,
                      height: double.infinity,
                      child: Stack(
                        children: [
                          Positioned(
                            // component14WpF (375:819)
                            left: 0*fem,
                            top: 34*fem,
                            child: Container(
                              width: 283*fem,
                              height: 254*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // component12Sxo (I375:819;356:379)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(0*fem, 0.98*fem, 0*fem, 0*fem),
                                      width: 283*fem,
                                      height: 130*fem,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // autogroupueqmYkw (CJ3AwMkrgKgXA59M4xUeqm)
                                            width: 321.56*fem,
                                            height: 129.02*fem,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // line44sHR (I375:819;356:380)
                                                  left: 4.564453125*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 129.02*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line46aSj (I375:819;356:381)
                                                  left: 0*fem,
                                                  top: 3.3484649658*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 321.56*fem,
                                                      height: 5*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line486vs (I375:819;356:382)
                                                  left: 0*fem,
                                                  top: 64.0151519775*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 278.44*fem,
                                                      height: 5*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line452Jj (I375:819;356:384)
                                                  left: 282.9907226562*fem,
                                                  top: 0.3282775879*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 128.69*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line51YXy (I375:819;356:385)
                                                  left: 213.3842773438*fem,
                                                  top: 0.3282775879*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 128.69*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line49UAj (I375:819;356:387)
                                                  left: 143.77734375*fem,
                                                  top: 0.3282775879*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 128.69*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // component29zes (I375:819;373:733)
                                                  left: 11*fem,
                                                  top: 69.0151519775*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 50*fem,
                                                      height: 45*fem,
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Image.asset(
                                                          'assets/page-1/images/component-29.png',
                                                          width: 50*fem,
                                                          height: 45*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // component306T1 (I375:819;373:847)
                                                  left: 80*fem,
                                                  top: 70.0151519775*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 50*fem,
                                                      height: 45*fem,
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Image.asset(
                                                          'assets/page-1/images/component-29.png',
                                                          width: 50*fem,
                                                          height: 45*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // component31nqd (I375:819;373:853)
                                                  left: 152*fem,
                                                  top: 69.0151519775*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 50*fem,
                                                      height: 45*fem,
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Image.asset(
                                                          'assets/page-1/images/component-29.png',
                                                          width: 50*fem,
                                                          height: 45*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // line47gw1 (I375:819;356:383)
                                            width: 278.44*fem,
                                            height: 5*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0xff88d498),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // component13FDR (I375:819;356:412)
                                    left: 0*fem,
                                    top: 124*fem,
                                    child: Container(
                                      width: 283*fem,
                                      height: 130*fem,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // autogroupagt1Zzo (CJ3CBzLW8U9nY5Rr5RagT1)
                                            width: 321.56*fem,
                                            height: 130*fem,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // line44Hvo (I375:819;356:413)
                                                  left: 4.564453125*fem,
                                                  top: 0.9848480225*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 129.02*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line46D3m (I375:819;356:414)
                                                  left: 0*fem,
                                                  top: 4.3333129883*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 321.56*fem,
                                                      height: 5*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line488Rd (I375:819;356:415)
                                                  left: 0*fem,
                                                  top: 65*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 278.44*fem,
                                                      height: 5*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line45eum (I375:819;356:417)
                                                  left: 282.9907226562*fem,
                                                  top: 1.3131256104*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 128.69*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line51BPu (I375:819;356:418)
                                                  left: 213.3842773438*fem,
                                                  top: 1.3131256104*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 128.69*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line49uao (I375:819;356:420)
                                                  left: 143.77734375*fem,
                                                  top: 1.3131256104*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 128.69*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // line571dq (I375:819;356:429)
                                                  left: 69*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 5*fem,
                                                      height: 130*fem,
                                                      child: Container(
                                                        decoration: BoxDecoration (
                                                          color: Color(0xff88d498),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // component29Xs5 (I375:819;373:745)
                                                  left: 11*fem,
                                                  top: 72*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 50*fem,
                                                      height: 45*fem,
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Image.asset(
                                                          'assets/page-1/images/component-29.png',
                                                          width: 50*fem,
                                                          height: 45*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // component322Yw (I375:819;373:859)
                                                  left: 80*fem,
                                                  top: 72*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 50*fem,
                                                      height: 45*fem,
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Image.asset(
                                                          'assets/page-1/images/component-29.png',
                                                          width: 50*fem,
                                                          height: 45*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // component337qH (I375:819;373:865)
                                                  left: 152*fem,
                                                  top: 72*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 50*fem,
                                                      height: 45*fem,
                                                      child: TextButton(
                                                        onPressed: () {},
                                                        style: TextButton.styleFrom (
                                                          padding: EdgeInsets.zero,
                                                        ),
                                                        child: Image.asset(
                                                          'assets/page-1/images/component-29.png',
                                                          width: 50*fem,
                                                          height: 45*fem,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // line471Qs (I375:819;356:416)
                                            width: 278.44*fem,
                                            height: 5*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0xff88d498),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // component30Mjd (I375:819;373:799)
                                    left: 221*fem,
                                    top: 9*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 50*fem,
                                        height: 45*fem,
                                        child: TextButton(
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Image.asset(
                                            'assets/page-1/images/component-29.png',
                                            width: 50*fem,
                                            height: 45*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // component31Fa7 (I375:819;373:800)
                                    left: 221*fem,
                                    top: 70*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 50*fem,
                                        height: 45*fem,
                                        child: TextButton(
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Image.asset(
                                            'assets/page-1/images/component-29.png',
                                            width: 50*fem,
                                            height: 45*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // component329Qb (I375:819;373:801)
                                    left: 221*fem,
                                    top: 135*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 50*fem,
                                        height: 45*fem,
                                        child: TextButton(
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Image.asset(
                                            'assets/page-1/images/component-29.png',
                                            width: 50*fem,
                                            height: 45*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // component293F5 (I375:819;373:802)
                                    left: 221*fem,
                                    top: 196*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 50*fem,
                                        height: 45*fem,
                                        child: TextButton(
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Image.asset(
                                            'assets/page-1/images/component-29.png',
                                            width: 50*fem,
                                            height: 45*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // line56Xg3 (I375:819;356:368)
                                    left: 69*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 5*fem,
                                        height: 130*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // component20FM9 (375:818)
                            left: 224*fem,
                            top: 0*fem,
                            child: Container(
                              width: 37*fem,
                              height: 35*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // abPCT (I375:818;356:535)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 37*fem,
                                        height: 35*fem,
                                        child: Text(
                                          'CD',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Nunito',
                                            fontSize: 25*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.3625*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // line60Ujh (I375:818;356:538)
                                    left: 19.9833984375*fem,
                                    top: 3*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 15.03*fem,
                                        height: 4*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // component18Prf (375:816)
                            left: 83*fem,
                            top: 0*fem,
                            child: Container(
                              width: 37*fem,
                              height: 35*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // abvrb (I375:816;356:533)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 37*fem,
                                        height: 35*fem,
                                        child: Text(
                                          'CD',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Nunito',
                                            fontSize: 25*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.3625*ffem/fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // line593AX (I375:816;356:537)
                                    left: 2*fem,
                                    top: 3*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 16*fem,
                                        height: 4*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // component16ZPm (375:814)
                            left: 11*fem,
                            top: 0*fem,
                            child: Container(
                              width: 37*fem,
                              height: 35*fem,
                              child: Center(
                                child: Text(
                                  'CD',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // cdSCf (375:812)
                            left: 155*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 37*fem,
                                height: 35*fem,
                                child: Text(
                                  'CD',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Nunito',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w900,
                                    height: 1.3625*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupwqszw9R (CJ39P9rAMMQDaxQWGgWQsZ)
              left: 178*fem,
              top: 285*fem,
              child: Container(
                width: 22*fem,
                height: 35*fem,
                child: Center(
                  child: Text(
                    'E',
                    style: SafeGoogleFont (
                      'Nunito',
                      fontSize: 25*ffem,
                      fontWeight: FontWeight.w900,
                      height: 1.3625*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // component36pj1 (382:1998)
              left: 82*fem,
              top: 688*fem,
              child: Container(
                width: 200*fem,
                height: 52*fem,
                decoration: BoxDecoration (
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // rectangle43tis (375:972)
                      left: 21.6000976562*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 156.8*fem,
                          height: 52*fem,
                          //Botao Outra parte da tabela (E)
                          child: TextButton(
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) => MapaCinco2()));
                            },
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(10*fem),
                                border: Border.all(color: Color(0xff000000)),
                                color: Color(0xffdfee36),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tabeladoeP9q (375:973)
                      left: 45*fem,
                      top: 13*fem,
                      child: Align(
                        child: SizedBox(
                          width: 110*fem,
                          height: 26*fem,
                          child: Text(
                            'Tabela do E:',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 18.5*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}