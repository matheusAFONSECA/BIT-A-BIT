import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class TabDuasPasso extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge21M91 (392:1142)
        padding: EdgeInsets.fromLTRB(24*fem, 50*fem, 23*fem, 37*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // passoapassodatabeladaverdadede (392:1144)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 552*fem),
              constraints: BoxConstraints (
                maxWidth: 313*fem,
              ),
              child: Text(
                'Passo a passo da tabela da verdade de 2 variáveis:',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroupm33vM2X (CJ3dZLuBzdygd4okxCM33V)
              margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 11*fem, 0*fem),
              width: double.infinity,
              height: 92*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group43fou (392:1145)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 26*fem, 17*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3yy1 (I392:1145;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-6qD.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group3185D (392:1152)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 0*fem),
                    //Botao Download
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(23*fem, 24*fem, 23*fem, 24*fem),
                        width: 126*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // downloadempdfjqh (I392:1152;201:117)
                          child: SizedBox(
                            child: Container(
                              constraints: BoxConstraints (
                                maxWidth: 80*fem,
                              ),
                              child: Text(
                                'Download\nem PDF',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group43eBy (392:1148)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 17*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1wgs (I392:1148;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151rYw (I392:1148;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-C1u.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}