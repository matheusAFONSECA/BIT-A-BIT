import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // frame13H11 (254:419)
        width: double.infinity,
        height: 252*fem,
        child: Stack(
          children: [
            Positioned(
              // androidkeyboarddatedarkgo1hh (254:418)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                width: 360*fem,
                height: 206*fem,
                child: Container(
                  // numberkeyboardKyH (I254:418;242:8330)
                  padding: EdgeInsets.fromLTRB(4*fem, 7*fem, 6*fem, 8*fem),
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    color: Color(0xff292e32),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // autogroupzrfdqgj (CJ2t8WRsPZArt5anEeZRFD)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                        width: 84*fem,
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // koh (I254:418;242:8387)
                              width: double.infinity,
                              height: 44*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangle78T (I254:418;242:8388)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Container(
                                      width: 84*fem,
                                      height: 44*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/vector-Fwu.png',
                                          ),
                                        ),
                                      ),
                                      child: Center(
                                        // vectorRQ3 (I254:418;242:8390)
                                        child: SizedBox(
                                          width: 84*fem,
                                          height: 44*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/vector.png',
                                            width: 84*fem,
                                            height: 44*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // 9aw (I254:418;242:8391)
                                    left: 33.5*fem,
                                    top: 3*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 17*fem,
                                        height: 36*fem,
                                        child: Text(
                                          '1',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 30*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xfffcffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 5*fem,
                            ),
                            Container(
                              // RHZ (I254:418;242:8372)
                              width: double.infinity,
                              height: 44*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangleNib (I254:418;242:8373)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Container(
                                      width: 84*fem,
                                      height: 44*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/vector-8rB.png',
                                          ),
                                        ),
                                      ),
                                      child: Center(
                                        // vector6Ph (I254:418;242:8375)
                                        child: SizedBox(
                                          width: 84*fem,
                                          height: 44*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/vector-BsV.png',
                                            width: 84*fem,
                                            height: 44*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // pKh (I254:418;242:8376)
                                    left: 33.5*fem,
                                    top: 3*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 17*fem,
                                        height: 36*fem,
                                        child: Text(
                                          '4',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 30*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xfffcffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 5*fem,
                            ),
                            Container(
                              // som (I254:418;242:8357)
                              width: double.infinity,
                              height: 44*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // rectangleDcj (I254:418;242:8358)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Container(
                                      width: 84*fem,
                                      height: 44*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/vector-8Ph.png',
                                          ),
                                        ),
                                      ),
                                      child: Center(
                                        // vector8jh (I254:418;242:8360)
                                        child: SizedBox(
                                          width: 84*fem,
                                          height: 44*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/vector-mh1.png',
                                            width: 84*fem,
                                            height: 44*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // J1u (I254:418;242:8361)
                                    left: 33.5*fem,
                                    top: 3*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 17*fem,
                                        height: 36*fem,
                                        child: Text(
                                          '7',
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 30*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xfffcffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 5*fem,
                            ),
                            Container(
                              // rectanglePJF (I254:418;242:8343)
                              width: double.infinity,
                              height: 44*fem,
                              decoration: BoxDecoration (
                                image: DecorationImage (
                                  fit: BoxFit.cover,
                                  image: AssetImage (
                                    'assets/page-1/images/vector-myH.png',
                                  ),
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  '0',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 32*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xfffcffff),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // autogroupqwcs3No (CJ2taVgZvj7qztWaGQqwcs)
                        width: 261*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // dotxVm (I254:418;242:8332)
                              left: 89*fem,
                              top: 147*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 84*fem,
                                  height: 44*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/dot.png',
                                    width: 84*fem,
                                    height: 44*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // r5M (I254:418;242:8337)
                              left: 0*fem,
                              top: 1*fem,
                              child: Container(
                                width: 261*fem,
                                height: 190*fem,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // rectangleMno (I254:418;253:397)
                                      margin: EdgeInsets.fromLTRB(177*fem, 0*fem, 0*fem, 102*fem),
                                      width: 84*fem,
                                      height: 44*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/vector-8Lw.png',
                                          ),
                                        ),
                                      ),
                                      child: Container(
                                        // rectangleSpF (I254:418;253:400)
                                        width: double.infinity,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/vector-9Xd.png',
                                            ),
                                          ),
                                        ),
                                        child: Center(
                                          // vectorCYX (I254:418;253:402)
                                          child: SizedBox(
                                            width: 84*fem,
                                            height: 44*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-8i3.png',
                                              width: 84*fem,
                                              height: 44*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // rectangle6to (I254:418;242:8338)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 177*fem, 0*fem),
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/vector-ywu.png',
                                          ),
                                        ),
                                      ),
                                      child: Center(
                                        // vectorzDV (I254:418;242:8340)
                                        child: SizedBox(
                                          width: 84*fem,
                                          height: 44*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/vector-Yrs.png',
                                            width: 84*fem,
                                            height: 44*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // 4z3 (I254:418;242:8347)
                              left: 89*fem,
                              top: 98*fem,
                              child: Container(
                                width: 84*fem,
                                height: 44*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // rectangleahV (I254:418;242:8348)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Container(
                                        width: 84*fem,
                                        height: 44*fem,
                                        decoration: BoxDecoration (
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/vector-HrF.png',
                                            ),
                                          ),
                                        ),
                                        child: Center(
                                          // vectorHM1 (I254:418;242:8350)
                                          child: SizedBox(
                                            width: 84*fem,
                                            height: 44*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-NBy.png',
                                              width: 84*fem,
                                              height: 44*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // 1no (I254:418;242:8351)
                                      left: 33.5*fem,
                                      top: 3*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 17*fem,
                                          height: 36*fem,
                                          child: Text(
                                            '9',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 30*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1725*ffem/fem,
                                              color: Color(0xfffcffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // hQj (I254:418;242:8352)
                              left: 0*fem,
                              top: 98*fem,
                              child: Container(
                                width: 84*fem,
                                height: 44*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // rectangle2C7 (I254:418;242:8353)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Container(
                                        width: 84*fem,
                                        height: 44*fem,
                                        decoration: BoxDecoration (
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/vector-PNP.png',
                                            ),
                                          ),
                                        ),
                                        child: Center(
                                          // vectorwK5 (I254:418;242:8355)
                                          child: SizedBox(
                                            width: 84*fem,
                                            height: 44*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-HzP.png',
                                              width: 84*fem,
                                              height: 44*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // 4Ph (I254:418;242:8356)
                                      left: 33.5*fem,
                                      top: 3*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 17*fem,
                                          height: 36*fem,
                                          child: Text(
                                            '8',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 30*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1725*ffem/fem,
                                              color: Color(0xfffcffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // knK (I254:418;242:8362)
                              left: 89*fem,
                              top: 49*fem,
                              child: Container(
                                width: 84*fem,
                                height: 44*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // rectangleUyD (I254:418;242:8363)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Container(
                                        width: 84*fem,
                                        height: 44*fem,
                                        decoration: BoxDecoration (
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/vector-8Hu.png',
                                            ),
                                          ),
                                        ),
                                        child: Center(
                                          // vectorQM5 (I254:418;242:8365)
                                          child: SizedBox(
                                            width: 84*fem,
                                            height: 44*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-FJ7.png',
                                              width: 84*fem,
                                              height: 44*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // XRh (I254:418;242:8366)
                                      left: 33.5*fem,
                                      top: 3*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 17*fem,
                                          height: 36*fem,
                                          child: Text(
                                            '6',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 30*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1725*ffem/fem,
                                              color: Color(0xfffcffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // nMd (I254:418;242:8367)
                              left: 0*fem,
                              top: 49*fem,
                              child: Container(
                                width: 84*fem,
                                height: 44*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // rectangle6t7 (I254:418;242:8368)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Container(
                                        width: 84*fem,
                                        height: 44*fem,
                                        decoration: BoxDecoration (
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/vector-Lo1.png',
                                            ),
                                          ),
                                        ),
                                        child: Center(
                                          // vectorDC3 (I254:418;242:8370)
                                          child: SizedBox(
                                            width: 84*fem,
                                            height: 44*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-XLB.png',
                                              width: 84*fem,
                                              height: 44*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // khm (I254:418;242:8371)
                                      left: 33.5*fem,
                                      top: 3*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 17*fem,
                                          height: 36*fem,
                                          child: Text(
                                            '5',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 30*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1725*ffem/fem,
                                              color: Color(0xfffcffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // 3wm (I254:418;242:8377)
                              left: 89*fem,
                              top: 0*fem,
                              child: Container(
                                width: 84*fem,
                                height: 44*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // rectangleago (I254:418;242:8378)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Container(
                                        width: 84*fem,
                                        height: 44*fem,
                                        decoration: BoxDecoration (
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/vector-9ef.png',
                                            ),
                                          ),
                                        ),
                                        child: Center(
                                          // vectorthV (I254:418;242:8380)
                                          child: SizedBox(
                                            width: 84*fem,
                                            height: 44*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-ZLB.png',
                                              width: 84*fem,
                                              height: 44*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // Qvj (I254:418;242:8381)
                                      left: 33.5*fem,
                                      top: 3*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 17*fem,
                                          height: 36*fem,
                                          child: Text(
                                            '3',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 30*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1725*ffem/fem,
                                              color: Color(0xfffcffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // uMh (I254:418;242:8382)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                width: 84*fem,
                                height: 44*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // rectangleDtB (I254:418;242:8383)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Container(
                                        width: 84*fem,
                                        height: 44*fem,
                                        decoration: BoxDecoration (
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/vector-hBd.png',
                                            ),
                                          ),
                                        ),
                                        child: Center(
                                          // vectorv1u (I254:418;242:8385)
                                          child: SizedBox(
                                            width: 84*fem,
                                            height: 44*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/vector-88X.png',
                                              width: 84*fem,
                                              height: 44*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // 3sD (I254:418;242:8386)
                                      left: 33.5*fem,
                                      top: 3*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 17*fem,
                                          height: 36*fem,
                                          child: Text(
                                            '2',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 30*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1725*ffem/fem,
                                              color: Color(0xfffcffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              // d9fM (I254:418;253:384)
                              left: 31*fem,
                              top: 151*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 20*fem,
                                  height: 36*fem,
                                  child: Text(
                                    'D',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // e2DM (I254:418;253:385)
                              left: 121*fem,
                              top: 150*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 18*fem,
                                  height: 36*fem,
                                  child: Text(
                                    'E',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // rectangleXA7 (I254:418;251:322)
                              left: 177*fem,
                              top: 148*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 84*fem,
                                  height: 41.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/rectangle.png',
                                    width: 84*fem,
                                    height: 41.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector1LB (I254:418;253:405)
                              left: 177*fem,
                              top: 50*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 84*fem,
                                  height: 44*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-pf1.png',
                                    width: 84*fem,
                                    height: 44*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorWXq (I254:418;251:329)
                              left: 177*fem,
                              top: 99*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 84*fem,
                                  height: 41.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-ZNP.png',
                                    width: 84*fem,
                                    height: 41.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorRPu (I254:418;251:324)
                              left: 177*fem,
                              top: 148*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 84*fem,
                                  height: 41.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-cgP.png',
                                    width: 84*fem,
                                    height: 41.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // aYjR (I254:418;253:410)
                              left: 209*fem,
                              top: 4*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 20*fem,
                                  height: 36*fem,
                                  child: Text(
                                    'A',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // brEK (I254:418;253:411)
                              left: 209*fem,
                              top: 53*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 19*fem,
                                  height: 36*fem,
                                  child: Text(
                                    'B',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // cmMH (I254:418;253:412)
                              left: 209*fem,
                              top: 101*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 20*fem,
                                  height: 36*fem,
                                  child: Text(
                                    'C',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // fUWb (I254:418;253:413)
                              left: 209*fem,
                              top: 151*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 17*fem,
                                  height: 36*fem,
                                  child: Text(
                                    'F',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 30*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // ckyu (253:386)
              left: 37*fem,
              top: 206*fem,
              child: Align(
                child: SizedBox(
                  width: 20*fem,
                  height: 36*fem,
                  child: Text(
                    'C',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 30*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fepP (253:395)
              left: 305*fem,
              top: 206*fem,
              child: Align(
                child: SizedBox(
                  width: 17*fem,
                  height: 36*fem,
                  child: Text(
                    'F',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 30*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle23LSK (253:409)
              left: 0*fem,
              top: 206*fem,
              child: Align(
                child: SizedBox(
                  width: 360*fem,
                  height: 46*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff282d31),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group33bd (242:8402)
              left: 93*fem,
              top: 202*fem,
              child: Align(
                child: SizedBox(
                  width: 84*fem,
                  height: 44*fem,
                  child: Image.asset(
                    'assets/page-1/images/group-3.png',
                    width: 84*fem,
                    height: 44*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // actionbuttonwh1 (242:8407)
              left: 182*fem,
              top: 202*fem,
              child: Align(
                child: SizedBox(
                  width: 84*fem,
                  height: 44*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/action-button.png',
                      width: 84*fem,
                      height: 44*fem,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}