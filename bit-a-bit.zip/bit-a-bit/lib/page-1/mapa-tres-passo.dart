import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class MapaTresPasso extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge13T51 (382:1794)
        padding: EdgeInsets.fromLTRB(20*fem, 50*fem, 15.01*fem, 37*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // component35y3M (382:1695)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 370*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupwmou67y (CJ3Kr25dvmsxYyieX6WMou)
                    margin: EdgeInsets.fromLTRB(55*fem, 0*fem, 24.99*fem, 7.5*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // component81kj (382:1698)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 25*fem, 0*fem),
                          width: 42*fem,
                          height: 41*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // bcLY7 (I382:1698;347:966)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 42*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'BC',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line552Qw (I382:1698;347:973)
                                left: 0*fem,
                                top: 4*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 42*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // component9YPH (382:1699)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 28*fem, 0*fem),
                          width: 42*fem,
                          height: 41*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // bcgEb (I382:1699;347:967)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 42*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'BC',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line53AfZ (I382:1699;347:971)
                                left: 0*fem,
                                top: 4*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // bcgto (I382:1696;347:968)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 1*fem),
                          child: Text(
                            'BC',
                            style: SafeGoogleFont (
                              'Nunito',
                              fontSize: 30*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.3625*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Container(
                          // component10R5h (382:1700)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                          width: 42*fem,
                          height: 41*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // bcYw1 (I382:1700;347:969)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 42*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'BC',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line54rwh (382:1703)
                                left: 22*fem,
                                top: 5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20.02*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupmqj5BUB (CJ3L3BRhxGKS4JPNE1Mqj5)
                    width: double.infinity,
                    height: 201.5*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // component11iyu (382:1697)
                          margin: EdgeInsets.fromLTRB(0*fem, 13.5*fem, 9*fem, 39*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // autogroupjxyoesZ (CJ3LAvhoLwXvEhJD5cJxYo)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 26*fem),
                                padding: EdgeInsets.fromLTRB(4*fem, 18*fem, 0*fem, 23*fem),
                                width: 27*fem,
                                height: 82*fem,
                                child: Container(
                                  // autogroupgwqdZzX (CJ3LF1RLFRgNJvchKGgWqD)
                                  width: double.infinity,
                                  height: double.infinity,
                                  child: Center(
                                    child: Text(
                                      'A',
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Text(
                                // a5T5 (I382:1697;347:965)
                                'A',
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 30*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // component7RWw (382:1701)
                          width: 287.99*fem,
                          height: double.infinity,
                          child: Container(
                            // autogroupncmmPCs (CJ3LizchbcPjfeEKW6Ncmm)
                            width: double.infinity,
                            height: 196.5*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // line44XK5 (I382:1701;347:954)
                                  left: 4.564453125*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 196.5*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line462Wj (I382:1701;347:957)
                                  left: 4.564453125*fem,
                                  top: 5.1000061035*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 278.44*fem,
                                      height: 5*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line48YV5 (I382:1701;347:959)
                                  left: 0*fem,
                                  top: 97.5*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 278.44*fem,
                                      height: 5*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line51sGT (I382:1701;347:962)
                                  left: 213.3842773438*fem,
                                  top: 0.5*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 196*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line49zM5 (I382:1701;347:960)
                                  left: 143.77734375*fem,
                                  top: 0.5*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 196*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line497gb (382:1702)
                                  left: 77*fem,
                                  top: 3.5*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 191*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouplwepctF (CJ3KZSivTTT7UpcDopLwEP)
              margin: EdgeInsets.fromLTRB(13*fem, 0*fem, 18.99*fem, 0*fem),
              width: double.infinity,
              height: 92*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group308rb (382:1795)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 26*fem, 17*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3ZS7 (I382:1795;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-pXZ.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group30gmd (382:1798)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 0*fem),
                    //Botao Download
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(23*fem, 24*fem, 23*fem, 24*fem),
                        width: 126*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // downloadempdfDuy (I382:1798;201:117)
                          child: SizedBox(
                            child: Container(
                              constraints: BoxConstraints (
                                maxWidth: 80*fem,
                              ),
                              child: Text(
                                'Download\nem PDF',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group308X9 (382:1801)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 17*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse13e7 (I382:1801;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151ZsM (I382:1801;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-Y5m.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}