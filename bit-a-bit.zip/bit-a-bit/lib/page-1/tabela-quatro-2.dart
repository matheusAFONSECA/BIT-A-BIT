import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'tabela-quatro-passo.dart';

class TabelaQuatro2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge25nfq (399:1188)
        padding: EdgeInsets.fromLTRB(33.02*fem, 49.56*fem, 26*fem, 29*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // component40uEf (399:1189)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
              width: double.infinity,
              height: 610.44*fem,
              child: Stack(
                children: [
                  Positioned(
                    // component39EGw (I399:1189;397:1102)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 300.98*fem,
                      height: 340.39*fem,
                      child: Container(
                        // autogroupebv7xij (CJ3k6f1AJPgSdBcZ66Ebv7)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                        width: double.infinity,
                        height: 336.39*fem,
                        child: Container(
                          // autogrouparu975q (CJ3kNu36dseZKgwg7CARu9)
                          width: 295.97*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // line632yV (I399:1189;397:1102;392:1114)
                                left: 3.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line69Ygw (I399:1189;397:1102;392:1120)
                                left: 203.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line68fmZ (I399:1189;397:1102;392:1119)
                                left: 103.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line64z39 (I399:1189;397:1102;392:1115)
                                left: 0*fem,
                                top: 3.1656188965*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line72JpX (I399:1189;397:1102;392:1123)
                                left: 0*fem,
                                top: 201.6824188232*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line7331R (I399:1189;397:1102;392:1127)
                                left: 0*fem,
                                top: 272.5812683105*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line71M27 (I399:1189;397:1102;392:1122)
                                left: 0*fem,
                                top: 133.1468658447*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line70GPy (I399:1189;397:1102;392:1121)
                                left: 0*fem,
                                top: 66.9745788574*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // ai15 (I399:1189;397:1132)
                                left: 37.9794921875*fem,
                                top: 14.4390258789*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 23*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'A',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // bbKm (I399:1189;397:1133)
                                left: 136.9794921875*fem,
                                top: 14.4390258789*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 22*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'B',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // sQo1 (I399:1189;397:1134)
                                left: 234.9794921875*fem,
                                top: 14.4390258789*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'S',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // component39K9H (I399:1189;397:1116)
                    left: 0*fem,
                    top: 270.0487365723*fem,
                    child: Container(
                      width: 300.98*fem,
                      height: 340.39*fem,
                      child: Container(
                        // autogrouph2r53LB (CJ3mMnZyTHqoZfa1dph2R5)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                        width: double.infinity,
                        height: 336.39*fem,
                        child: Container(
                          // autogroupy5pmBBV (CJ3mbnAf8PCVF2NpjEY5PM)
                          width: 295.97*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // line63v95 (I399:1189;397:1116;392:1114)
                                left: 3.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line69qG3 (I399:1189;397:1116;392:1120)
                                left: 203.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line68MkB (I399:1189;397:1116;392:1119)
                                left: 103.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line726By (I399:1189;397:1116;392:1123)
                                left: 0*fem,
                                top: 201.6824188232*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line73os5 (I399:1189;397:1116;392:1127)
                                left: 0*fem,
                                top: 272.5812683105*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line71jEw (I399:1189;397:1116;392:1122)
                                left: 0*fem,
                                top: 133.1468658447*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line70raT (I399:1189;397:1116;392:1121)
                                left: 0*fem,
                                top: 66.9745864868*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupogudyQB (CJ3jdkcKeAxwyqHfuLogud)
              margin: EdgeInsets.fromLTRB(2.98*fem, 0*fem, 4*fem, 0*fem),
              width: double.infinity,
              height: 92*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group43h5H (399:1190)
                    margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 28*fem, 18*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3WYX (I399:1190;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-vw9.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group44qqh (399:1233)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 27*fem, 0*fem),
                    //Botao Passo-a-passo
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => TabQuatroPasso()));
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(21*fem, 13*fem, 21*fem, 13*fem),
                        width: 126*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // resoluopassoapassoeYF (I399:1233;128:77)
                          child: SizedBox(
                            child: Container(
                              constraints: BoxConstraints (
                                maxWidth: 84*fem,
                              ),
                              child: Text(
                                'Resolução \npasso a passo',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group43Y7q (399:1191)
                    margin: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 18*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1r8X (I399:1191;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151N6s (I399:1191;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-8SB.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}