import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/page-1/tabela-quatro-2.dart';
import 'package:myapp/utils.dart';
import 'tabela-quatro-passo.dart';

class TabelaQuatro extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge24Dou (399:1141)
        padding: EdgeInsets.fromLTRB(33.02*fem, 49.56*fem, 26*fem, 45*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // component40vTR (399:1142)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
              width: double.infinity,
              height: 610.44*fem,
              child: Stack(
                children: [
                  Positioned(
                    // component39qaP (I399:1142;397:1102)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 300.98*fem,
                      height: 340.39*fem,
                      child: Container(
                        // autogrouphsbvmD9 (CJ3hPZrF6wNycYpDythsbV)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                        width: double.infinity,
                        height: 336.39*fem,
                        child: Container(
                          // autogroupfhqkhcb (CJ3hhPfsq934au73YLFHQK)
                          width: 295.97*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // line63S4P (I399:1142;397:1102;392:1114)
                                left: 3.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line69YdD (I399:1142;397:1102;392:1120)
                                left: 203.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line68GJK (I399:1142;397:1102;392:1119)
                                left: 103.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line64NcF (I399:1142;397:1102;392:1115)
                                left: 0*fem,
                                top: 3.1656188965*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line72tKh (I399:1142;397:1102;392:1123)
                                left: 0*fem,
                                top: 201.6824188232*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line73bzo (I399:1142;397:1102;392:1127)
                                left: 0*fem,
                                top: 272.5812683105*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line71XNf (I399:1142;397:1102;392:1122)
                                left: 0*fem,
                                top: 133.1468658447*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line703ro (I399:1142;397:1102;392:1121)
                                left: 0*fem,
                                top: 66.9745788574*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // aNPH (I399:1142;397:1132)
                                left: 37.9794921875*fem,
                                top: 14.4390258789*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 23*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'A',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // bs59 (I399:1142;397:1133)
                                left: 136.9794921875*fem,
                                top: 14.4390258789*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 22*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'B',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // sYwy (I399:1142;397:1134)
                                left: 234.9794921875*fem,
                                top: 14.4390258789*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 41*fem,
                                    child: Text(
                                      'S',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // component394QX (I399:1142;397:1116)
                    left: 0*fem,
                    top: 270.0487365723*fem,
                    child: Container(
                      width: 300.98*fem,
                      height: 340.39*fem,
                      child: Container(
                        // autogroupu7apbQT (CJ3idccXZsYTqfUwXYu7AP)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                        width: double.infinity,
                        height: 336.39*fem,
                        child: Container(
                          // autogroupizo5Xou (CJ3irrjTgqN1BJnKK4iZo5)
                          width: 295.97*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // line6354j (I399:1142;397:1116;392:1114)
                                left: 3.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line69aXH (I399:1142;397:1116;392:1120)
                                left: 203.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line68Hgb (I399:1142;397:1116;392:1119)
                                left: 103.1337890625*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 4*fem,
                                    height: 336.39*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line72CYf (I399:1142;397:1116;392:1123)
                                left: 0*fem,
                                top: 201.6824188232*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line738SK (I399:1142;397:1116;392:1127)
                                left: 0*fem,
                                top: 272.5812683105*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line713pB (I399:1142;397:1116;392:1122)
                                left: 0*fem,
                                top: 133.1468658447*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line70BQb (I399:1142;397:1116;392:1121)
                                left: 0*fem,
                                top: 66.9745864868*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 295.97*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xff88d498),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupkaishNw (CJ3gtVrM4nfjYTurnzkais)
              margin: EdgeInsets.fromLTRB(20.98*fem, 0*fem, 29*fem, 0*fem),
              width: double.infinity,
              height: 60*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group43d1h (399:1143)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41*fem, 2*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image33LK (I399:1143;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-zgP.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group43mn7 (399:1144)
                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 42*fem, 1*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1t63 (I399:1144;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151oD1 (I399:1144;143:101)
                              left: 0*fem,
                              top: 2.351348877*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-Na3.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group44WNK (399:1184)
                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                    //Botao segunda parte tabela
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => TabelaQuatro2()));
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: 58*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1REP (I399:1184;143:100)
                              left: 1.52734375*fem,
                              top: 3.1351318359*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1-Ybq.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151vgw (I399:1184;143:101)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-cBH.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}