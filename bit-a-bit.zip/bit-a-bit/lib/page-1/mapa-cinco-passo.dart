import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class MapaCincoPasso extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge18YX9 (382:2016)
        padding: EdgeInsets.fromLTRB(15*fem, 24*fem, 11*fem, 29*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // component37cmu (382:2175)
              margin: EdgeInsets.fromLTRB(159*fem, 0*fem, 156*fem, 13*fem),
              width: double.infinity,
              height: 34*fem,
              child: Stack(
                children: [
                  Positioned(
                    // eLC7 (382:2103)
                    left: 1*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 16*fem,
                        height: 35*fem,
                        child: Text(
                          'E',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line62BTd (382:2104)
                    left: 0*fem,
                    top: 1*fem,
                    child: Align(
                      child: SizedBox(
                        width: 19*fem,
                        height: 3*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // group32VUK (382:2017)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 14*fem),
              width: double.infinity,
              height: 288*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupf5np2DM (CJ3TmHtNf4C49RzeuLf5NP)
                    margin: EdgeInsets.fromLTRB(0*fem, 48*fem, 12*fem, 16*fem),
                    width: 37*fem,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // component15jNf (382:2024)
                          width: double.infinity,
                          height: 35*fem,
                          child: Center(
                            child: Text(
                              'AB',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 25*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // component17C1M (382:2022)
                          width: double.infinity,
                          height: 35*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // abKrf (I382:2022;356:533)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 37*fem,
                                    height: 35*fem,
                                    child: Text(
                                      'AB',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line59Dh9 (I382:2022;356:537)
                                left: 2*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 16*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Text(
                          // abKEP (382:2026)
                          'AB',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // component19FNw (382:2020)
                          width: double.infinity,
                          height: 35*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // abbhh (I382:2020;356:535)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 37*fem,
                                    height: 35*fem,
                                    child: Text(
                                      'AB',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line60JMD (I382:2020;356:538)
                                left: 19.9833984375*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 15.03*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupbknxc71 (CJ3U1XyeBXPnc2dwmPBKnX)
                    width: 283*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // component149cj (382:2018)
                          left: 0*fem,
                          top: 34*fem,
                          child: Container(
                            width: 283*fem,
                            height: 254*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // component125FV (I382:2018;356:379)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(0*fem, 0.98*fem, 0*fem, 0*fem),
                                    width: 283*fem,
                                    height: 130*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // autogrouplby9aT9 (CJ3UZ25BSywpt5xGj4LBy9)
                                          width: 321.56*fem,
                                          height: 129.02*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // line44uEX (I382:2018;356:380)
                                                left: 4.564453125*fem,
                                                top: 0*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 129.02*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line46RTm (I382:2018;356:381)
                                                left: 0*fem,
                                                top: 3.348449707*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 321.56*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line488sy (I382:2018;356:382)
                                                left: 0*fem,
                                                top: 64.0151367188*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 278.44*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line454Fq (I382:2018;356:384)
                                                left: 282.9907226562*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line51BLT (I382:2018;356:385)
                                                left: 213.3842773438*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line49h3u (I382:2018;356:387)
                                                left: 143.77734375*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // line47p8X (I382:2018;356:383)
                                          width: 278.44*fem,
                                          height: 5*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component13Zbu (I382:2018;356:412)
                                  left: 0*fem,
                                  top: 124*fem,
                                  child: Container(
                                    width: 283*fem,
                                    height: 130*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // autogroupacddscb (CJ3VpZny2BBbnddrtWacDD)
                                          width: 321.56*fem,
                                          height: 130*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // line44bHh (I382:2018;356:413)
                                                left: 4.564453125*fem,
                                                top: 0.9848632812*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 129.02*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line46JT1 (I382:2018;356:414)
                                                left: 0*fem,
                                                top: 4.3333129883*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 321.56*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line48E5m (I382:2018;356:415)
                                                left: 0*fem,
                                                top: 65*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 278.44*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line45AEK (I382:2018;356:417)
                                                left: 282.9907226562*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line51VXV (I382:2018;356:418)
                                                left: 213.3842773438*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line49RR9 (I382:2018;356:420)
                                                left: 143.77734375*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line57xAB (I382:2018;356:429)
                                                left: 69*fem,
                                                top: 0*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 130*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // line47HCT (I382:2018;356:416)
                                          width: 278.44*fem,
                                          height: 5*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line562Qw (I382:2018;356:368)
                                  left: 69*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 130*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component20AGF (382:2019)
                          left: 224*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abVJX (I382:2019;356:535)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'CD',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line60bMZ (I382:2019;356:538)
                                  left: 19.9833984375*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15.03*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component18ih5 (382:2021)
                          left: 83*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abroH (I382:2021;356:533)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'CD',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line59nB9 (I382:2021;356:537)
                                  left: 2*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 16*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component16VbM (382:2023)
                          left: 11*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Center(
                              child: Text(
                                'CD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // cdCEs (382:2025)
                          left: 155*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 37*fem,
                              height: 35*fem,
                              child: Text(
                                'CD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // erKR (382:2176)
              margin: EdgeInsets.fromLTRB(22*fem, 0*fem, 0*fem, 2*fem),
              child: Text(
                'E',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Nunito',
                  fontSize: 25*ffem,
                  fontWeight: FontWeight.w900,
                  height: 1.3625*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // group34LVV (382:2105)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 15*fem),
              width: double.infinity,
              height: 288*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroup3gjsE55 (CJ3Xyb2yxxdFNKW5aE3gJs)
                    margin: EdgeInsets.fromLTRB(0*fem, 48*fem, 12*fem, 16*fem),
                    width: 37*fem,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // component15Jaj (382:2112)
                          width: double.infinity,
                          height: 35*fem,
                          child: Center(
                            child: Text(
                              'AB',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 25*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // component173Rq (382:2110)
                          width: double.infinity,
                          height: 35*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // abzM5 (I382:2110;356:533)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 37*fem,
                                    height: 35*fem,
                                    child: Text(
                                      'AB',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line596Q7 (I382:2110;356:537)
                                left: 2*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 16*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Text(
                          // abQvb (382:2114)
                          'AB',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // component19jCB (382:2108)
                          width: double.infinity,
                          height: 35*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // abUfZ (I382:2108;356:535)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 37*fem,
                                    height: 35*fem,
                                    child: Text(
                                      'AB',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line60BZy (I382:2108;356:538)
                                left: 19.9833984375*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 15.03*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupwk3qWcF (CJ3YCLAkPAkh9V8VpUWk3q)
                    width: 283*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // component14fEF (382:2106)
                          left: 0*fem,
                          top: 34*fem,
                          child: Container(
                            width: 283*fem,
                            height: 254*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // component12z1d (I382:2106;356:379)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(0*fem, 0.98*fem, 0*fem, 0*fem),
                                    width: 283*fem,
                                    height: 130*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // autogroupg3bmGzj (CJ3Ygz1g12PXFWJjPeg3BM)
                                          width: 321.56*fem,
                                          height: 129.02*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // line44bn7 (I382:2106;356:380)
                                                left: 4.564453125*fem,
                                                top: 0*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 129.02*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line46Wu5 (I382:2106;356:381)
                                                left: 0*fem,
                                                top: 3.348449707*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 321.56*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line48Snj (I382:2106;356:382)
                                                left: 0*fem,
                                                top: 64.0151367188*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 278.44*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line45ZcT (I382:2106;356:384)
                                                left: 282.9907226562*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line51gBH (I382:2106;356:385)
                                                left: 213.3842773438*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line49c4w (I382:2106;356:387)
                                                left: 143.77734375*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // line47XSo (I382:2106;356:383)
                                          width: 278.44*fem,
                                          height: 5*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component13gab (I382:2106;356:412)
                                  left: 0*fem,
                                  top: 124*fem,
                                  child: Container(
                                    width: 283*fem,
                                    height: 130*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // autogroupv9vxDKd (CJ3ZoHVs5HLXJE4c5hv9vX)
                                          width: 321.56*fem,
                                          height: 130*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // line448Bh (I382:2106;356:413)
                                                left: 4.564453125*fem,
                                                top: 0.9848632812*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 129.02*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line46FGK (I382:2106;356:414)
                                                left: 0*fem,
                                                top: 4.3333129883*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 321.56*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line48JkP (I382:2106;356:415)
                                                left: 0*fem,
                                                top: 65*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 278.44*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line452RV (I382:2106;356:417)
                                                left: 282.9907226562*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line51Y8w (I382:2106;356:418)
                                                left: 213.3842773438*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line49sBD (I382:2106;356:420)
                                                left: 143.77734375*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line57o4s (I382:2106;356:429)
                                                left: 69*fem,
                                                top: 0*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 130*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // line47vQP (I382:2106;356:416)
                                          width: 278.44*fem,
                                          height: 5*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line565HH (I382:2106;356:368)
                                  left: 69*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 130*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component20bmR (382:2107)
                          left: 224*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abjcj (I382:2107;356:535)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'CD',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line60dTD (I382:2107;356:538)
                                  left: 19.9833984375*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15.03*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component18wyh (382:2109)
                          left: 83*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abfuh (I382:2109;356:533)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'CD',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line59MXd (I382:2109;356:537)
                                  left: 2*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 16*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component16UcF (382:2111)
                          left: 11*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Center(
                              child: Text(
                                'CD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // cdMvw (382:2113)
                          left: 155*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 37*fem,
                              height: 35*fem,
                              child: Text(
                                'CD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouptvuyFmR (CJ3TQJVM9RA2dPnSGDtVuy)
              margin: EdgeInsets.fromLTRB(18*fem, 0*fem, 32*fem, 0*fem),
              width: double.infinity,
              height: 58*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group31aYo (382:2027)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 64*fem, 0*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3zcX (I382:2027;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-Phq.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group37LAb (384:1011)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 52*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1FHZ (I384:1011;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151mFu (I384:1011;143:101)
                              left: 0*fem,
                              top: 2.3513183594*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-ztF.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  //Botao Voltar
                  TextButton(
                    // group33fs5 (382:2100)
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: 55*fem,
                      height: double.infinity,
                      child: Stack(
                        children: [
                          Positioned(
                            // ellipse1QJs (382:2101)
                            left: 1.5278320312*fem,
                            top: 3.1351318359*fem,
                            child: Align(
                              child: SizedBox(
                                width: 53.47*fem,
                                height: 54.86*fem,
                                child: Image.asset(
                                  'assets/page-1/images/ellipse-1.png',
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // whatsappimage20230726at91518Es (382:2102)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 55*fem,
                                height: 55.65*fem,
                                child: Image.asset(
                                  'assets/page-1/images/whatsappimage2023-07-26at915-1-K9y.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}