import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'tabela-tres-passo.dart';

class TabelaTres extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge2261M (397:1131)
        width: double.infinity,
        height: 800*fem,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Stack(
          children: [
            Positioned(
              // component40RZR (397:1130)
              left: 30*fem,
              top: 48*fem,
              child: Container(
                width: 300*fem,
                height: 608*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // component39Mhy (397:1102)
                      left: 3.0200195312*fem,
                      top: 1.5609741211*fem,
                      child: Container(
                        width: 300.98*fem,
                        height: 340.39*fem,
                        child: Container(
                          // autogroupicyutT1 (CJ3eFf5MLjk5ntKfmYiCyu)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                          width: double.infinity,
                          height: 336.39*fem,
                          child: Container(
                            // autogroupioyh2ZD (CJ3ea9YYLcKdWYB6iLioyh)
                            width: 295.97*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // line63Zp3 (I397:1102;392:1114)
                                  left: 3.1337890625*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 4*fem,
                                      height: 336.39*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line69g7y (I397:1102;392:1120)
                                  left: 203.1337890625*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 4*fem,
                                      height: 336.39*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line68Q3y (I397:1102;392:1119)
                                  left: 103.1337890625*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 4*fem,
                                      height: 336.39*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line64iKZ (I397:1102;392:1115)
                                  left: 0*fem,
                                  top: 3.1656188965*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line72qf5 (I397:1102;392:1123)
                                  left: 0*fem,
                                  top: 201.6824188232*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line73Zb5 (I397:1102;392:1127)
                                  left: 0*fem,
                                  top: 272.5812683105*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line71VDq (I397:1102;392:1122)
                                  left: 0*fem,
                                  top: 133.1468658447*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line70nyd (I397:1102;392:1121)
                                  left: 0*fem,
                                  top: 66.9745788574*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // aXAX (397:1132)
                                  left: 37.9799804688*fem,
                                  top: 14.4390258789*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 23*fem,
                                      height: 41*fem,
                                      child: Text(
                                        'A',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 30*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // bcxf (397:1133)
                                  left: 136.9799804688*fem,
                                  top: 14.4390258789*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 22*fem,
                                      height: 41*fem,
                                      child: Text(
                                        'B',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 30*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // s8RD (397:1134)
                                  left: 234.9799804688*fem,
                                  top: 14.4390258789*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 20*fem,
                                      height: 41*fem,
                                      child: Text(
                                        'S',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 30*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // component39DxT (397:1116)
                      left: 3.0200195312*fem,
                      top: 271.6097106934*fem,
                      child: Container(
                        width: 300.98*fem,
                        height: 340.39*fem,
                        child: Container(
                          // autogroupap3zkhV (CJ3fsH42JXFNgvpPR8ap3Z)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                          width: double.infinity,
                          height: 336.39*fem,
                          child: Container(
                            // autogroupwe2bVf5 (CJ3g9X5xe1DVPS9WSEWe2b)
                            width: 295.97*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // line63RYj (I397:1116;392:1114)
                                  left: 3.1337890625*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 4*fem,
                                      height: 336.39*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line698i3 (I397:1116;392:1120)
                                  left: 203.1337890625*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 4*fem,
                                      height: 336.39*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line68re3 (I397:1116;392:1119)
                                  left: 103.1337890625*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 4*fem,
                                      height: 336.39*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line721fM (I397:1116;392:1123)
                                  left: 0*fem,
                                  top: 201.6824188232*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line73wJ7 (I397:1116;392:1127)
                                  left: 0*fem,
                                  top: 272.5812683105*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line714tX (I397:1116;392:1122)
                                  left: 0*fem,
                                  top: 133.1468658447*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line70znB (I397:1116;392:1121)
                                  left: 0*fem,
                                  top: 66.9745864868*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 295.97*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group43iTH (397:1135)
              left: 33*fem,
              top: 695*fem,
              //Botao Menu
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                  width: 58*fem,
                  height: 58*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff000000)),
                    color: Color(0xffdfee36),
                    borderRadius: BorderRadius.circular(29*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    // image3Kxs (I397:1135;143:153)
                    child: SizedBox(
                      width: 33*fem,
                      height: 32*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-3-fr7.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group434fZ (397:1138)
              left: 271*fem,
              top: 695*fem,
              //Botao Voltar
              child: TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 55*fem,
                  height: 58*fem,
                  child: Stack(
                    children: [
                      Positioned(
                        // ellipse1BVH (I397:1138;143:100)
                        left: 0*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 53.47*fem,
                            height: 54.86*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-1.png',
                              width: 53.47*fem,
                              height: 54.86*fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // whatsappimage20230726at91515qZ (I397:1138;143:101)
                        left: 0*fem,
                        top: 2.351348877*fem,
                        child: Align(
                          child: SizedBox(
                            width: 55*fem,
                            height: 55.65*fem,
                            child: Image.asset(
                              'assets/page-1/images/whatsappimage2023-07-26at915-1-iLo.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // group43b3D (397:1141)
              left: 118*fem,
              top: 685*fem,
              //Botao Passo-a-passo
              child: TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => TabTresPasso()));
                },
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(21*fem, 13*fem, 21*fem, 13*fem),
                  width: 126*fem,
                  height: 92*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0xff000000)),
                    color: Color(0xffdfee36),
                    borderRadius: BorderRadius.circular(10*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    // resoluopassoapassoQmM (I397:1141;128:77)
                    child: SizedBox(
                      child: Container(
                        constraints: BoxConstraints (
                          maxWidth: 84*fem,
                        ),
                        child: Text(
                          'Resolução \npasso a passo',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}