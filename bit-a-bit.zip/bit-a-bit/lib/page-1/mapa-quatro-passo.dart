import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class MapaQuatroPasso extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // androidlarge1485m (382:1957)
        padding: EdgeInsets.fromLTRB(14*fem, 68*fem, 14*fem, 37*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff114b5f),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group32Dsu (382:1807)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 315*fem),
              width: double.infinity,
              height: 288*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupe73dMDR (CJ3NrS529g9QyV8qeUE73d)
                    margin: EdgeInsets.fromLTRB(0*fem, 48*fem, 12*fem, 16*fem),
                    width: 37*fem,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // component15U39 (382:1814)
                          width: double.infinity,
                          height: 35*fem,
                          child: Center(
                            child: Text(
                              'AB',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Nunito',
                                fontSize: 25*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.3625*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // component17wBd (382:1812)
                          width: double.infinity,
                          height: 35*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // abHWP (I382:1812;356:533)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 37*fem,
                                    height: 35*fem,
                                    child: Text(
                                      'AB',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line59yu1 (I382:1812;356:537)
                                left: 2*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 16*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Text(
                          // abGdD (382:1816)
                          'AB',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Nunito',
                            fontSize: 25*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.3625*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                        SizedBox(
                          height: 28*fem,
                        ),
                        Container(
                          // component19zJK (382:1810)
                          width: double.infinity,
                          height: 35*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // abk2b (I382:1810;356:535)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 37*fem,
                                    height: 35*fem,
                                    child: Text(
                                      'AB',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Nunito',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w900,
                                        height: 1.3625*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // line60e7y (I382:1810;356:538)
                                left: 19.9833984375*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 15.03*fem,
                                    height: 4*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouphagoxeT (CJ3P61WjQURggnDX8AHAGo)
                    width: 283*fem,
                    height: double.infinity,
                    child: Stack(
                      children: [
                        Positioned(
                          // component14WAB (382:1808)
                          left: 0*fem,
                          top: 34*fem,
                          child: Container(
                            width: 283*fem,
                            height: 254*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // component12DaP (I382:1808;356:379)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(0*fem, 0.98*fem, 0*fem, 0*fem),
                                    width: 283*fem,
                                    height: 130*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // autogroupaqxmWpP (CJ3PcQojyxyrFUF75mAqXM)
                                          width: 321.56*fem,
                                          height: 129.02*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // line44du1 (I382:1808;356:380)
                                                left: 4.564453125*fem,
                                                top: 0*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 129.02*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line46Ym5 (I382:1808;356:381)
                                                left: 0*fem,
                                                top: 3.348449707*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 321.56*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line48GSB (I382:1808;356:382)
                                                left: 0*fem,
                                                top: 64.0151367188*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 278.44*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line45BZ9 (I382:1808;356:384)
                                                left: 282.9907226562*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line516w1 (I382:1808;356:385)
                                                left: 213.3842773438*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line492pf (I382:1808;356:387)
                                                left: 143.77734375*fem,
                                                top: 0.3282470703*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // line47Y2K (I382:1808;356:383)
                                          width: 278.44*fem,
                                          height: 5*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // component13g8X (I382:1808;356:412)
                                  left: 0*fem,
                                  top: 124*fem,
                                  child: Container(
                                    width: 283*fem,
                                    height: 130*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // autogroup9lpzCMm (CJ3QkTk21rrBkrrLAF9LPZ)
                                          width: 321.56*fem,
                                          height: 130*fem,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                // line44vYf (I382:1808;356:413)
                                                left: 4.564453125*fem,
                                                top: 0.9848632812*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 129.02*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line46SG7 (I382:1808;356:414)
                                                left: 0*fem,
                                                top: 4.3333129883*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 321.56*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line489wD (I382:1808;356:415)
                                                left: 0*fem,
                                                top: 65*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 278.44*fem,
                                                    height: 5*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line45UyV (I382:1808;356:417)
                                                left: 282.9907226562*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line51c47 (I382:1808;356:418)
                                                left: 213.3842773438*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line498YF (I382:1808;356:420)
                                                left: 143.77734375*fem,
                                                top: 1.3131103516*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 128.69*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                // line57f2P (I382:1808;356:429)
                                                left: 69*fem,
                                                top: 0*fem,
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 5*fem,
                                                    height: 130*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        color: Color(0xff88d498),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // line47nMu (I382:1808;356:416)
                                          width: 278.44*fem,
                                          height: 5*fem,
                                          decoration: BoxDecoration (
                                            color: Color(0xff88d498),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line56jY3 (I382:1808;356:368)
                                  left: 69*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 5*fem,
                                      height: 130*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xff88d498),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component2044X (382:1809)
                          left: 224*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abZmy (I382:1809;356:535)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'CD',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line604ij (I382:1809;356:538)
                                  left: 19.9833984375*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15.03*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component18PW7 (382:1811)
                          left: 83*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // abvF9 (I382:1811;356:533)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 37*fem,
                                      height: 35*fem,
                                      child: Text(
                                        'CD',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Nunito',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w900,
                                          height: 1.3625*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // line59q7D (I382:1811;356:537)
                                  left: 2*fem,
                                  top: 3*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 16*fem,
                                      height: 4*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // component16kjy (382:1813)
                          left: 11*fem,
                          top: 0*fem,
                          child: Container(
                            width: 37*fem,
                            height: 35*fem,
                            child: Center(
                              child: Text(
                                'CD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // cdFAw (382:1815)
                          left: 155*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 37*fem,
                              height: 35*fem,
                              child: Text(
                                'CD',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupji1vjro (CJ3NXMnUAbG66wfdEsJi1V)
              margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 20*fem, 0*fem),
              width: double.infinity,
              height: 92*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group31G63 (382:1985)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 26*fem, 17*fem),
                    //Botao Menu
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12*fem, 13*fem, 13*fem, 13*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(29*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // image3sLj (I382:1985;143:153)
                          child: SizedBox(
                            width: 33*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-3-FpK.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group321C3 (382:1986)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28*fem, 0*fem),
                    //Botao Download
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(23*fem, 24*fem, 23*fem, 24*fem),
                        width: 126*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffdfee36),
                          borderRadius: BorderRadius.circular(10*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // downloadempdfp9V (I382:1986;201:117)
                          child: SizedBox(
                            child: Container(
                              constraints: BoxConstraints (
                                maxWidth: 80*fem,
                              ),
                              child: Text(
                                'Download\nem PDF',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Nunito',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w900,
                                  height: 1.3625*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group33iVm (382:1987)
                    margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 17*fem),
                    //Botao Voltar
                    child: TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 55*fem,
                        height: double.infinity,
                        child: Stack(
                          children: [
                            Positioned(
                              // ellipse1Ruy (I382:1987;143:100)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 53.47*fem,
                                  height: 54.86*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ellipse-1.png',
                                    width: 53.47*fem,
                                    height: 54.86*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // whatsappimage20230726at9151Yzb (I382:1987;143:101)
                              left: 0*fem,
                              top: 2.3513183594*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 55*fem,
                                  height: 55.65*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/whatsappimage2023-07-26at915-1-MR9.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}