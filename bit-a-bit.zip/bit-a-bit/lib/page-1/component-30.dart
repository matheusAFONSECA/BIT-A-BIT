import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1700;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // component30Rqy (390:1013)
        width: double.infinity,
        height: 206*fem,
        child: Container(
          // androidkeyboardaD5 (I390:1013;242:7850)
          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1340*fem, 0*fem),
          width: 360*fem,
          height: double.infinity,
          child: Container(
            // numberkeyboarduWF (I390:1013;242:7850;355:8843)
            padding: EdgeInsets.fromLTRB(49*fem, 7*fem, 49*fem, 8*fem),
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration (
              color: Color(0xff292e32),
            ),
            child: Container(
              // group27EHd (I390:1013;242:7850;355:8845)
              width: double.infinity,
              height: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupxtduxzK (CJ2xZiNdgaxs4xcGzsXtDu)
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // uPm (I390:1013;242:7850;355:8900)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectanglerpo (I390:1013;242:7850;355:8901)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-wQK.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectormRy (I390:1013;242:7850;355:8903)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-pAb.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // Hv7 (I390:1013;242:7850;355:8904)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'A',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // 9xK (I390:1013;242:7850;355:8894)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleWns (I390:1013;242:7850;355:8895)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-DfV.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorETy (I390:1013;242:7850;355:8897)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-vAj.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // xes (I390:1013;242:7850;355:8898)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 19*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'B',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // abc3wD (I390:1013;242:7850;355:8899)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 27*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'ABC',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // wFu (I390:1013;242:7850;355:8888)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleVHR (I390:1013;242:7850;355:8889)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-AKy.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorQ9V (I390:1013;242:7850;355:8891)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-iS3.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // YFh (I390:1013;242:7850;355:8892)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'C',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // def3CT (I390:1013;242:7850;355:8893)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 25*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'DEF',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 5*fem,
                  ),
                  Container(
                    // autogroupsiijvX9 (CJ2xq86dBUn9qLV8nXsiij)
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // GL7 (I390:1013;242:7850;355:8882)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectanglepMd (I390:1013;242:7850;355:8883)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-i4f.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorLKy (I390:1013;242:7850;355:8885)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-PXM.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // UBH (I390:1013;242:7850;355:8886)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 20*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'D',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // ghib11 (I390:1013;242:7850;355:8887)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 24*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'GHI',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // HPd (I390:1013;242:7850;355:8876)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle37u (I390:1013;242:7850;355:8877)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-n4P.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vector9gj (I390:1013;242:7850;355:8879)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-fcB.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // gwZ (I390:1013;242:7850;355:8880)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 18*fem,
                                    height: 36*fem,
                                    child: Text(
                                      'E',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // jklCf1 (I390:1013;242:7850;355:8881)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 25*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'JKL',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // Vu1 (I390:1013;242:7850;355:8870)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectanglef2o (I390:1013;242:7850;355:8871)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-3G3.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectornNK (I390:1013;242:7850;355:8873)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-Ufh.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // iWs (I390:1013;242:7850;355:8874)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 6*fem,
                                    height: 36*fem,
                                    child: Text(
                                      '‘',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // mnoDyR (I390:1013;242:7850;355:8875)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 32*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'MNO',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 5*fem,
                  ),
                  Container(
                    // autogroupwwlbKFm (CJ2y8HGhe1Wn4PDLxcwwLb)
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // Fv7 (I390:1013;242:7850;355:8864)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleDM9 (I390:1013;242:7850;355:8865)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-MnX.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorYPR (I390:1013;242:7850;355:8867)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-q51.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // V3m (I390:1013;242:7850;355:8868)
                                left: 20*fem,
                                top: 3*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 11*fem,
                                    height: 36*fem,
                                    child: Text(
                                      '(',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffcffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // prqszWK (I390:1013;242:7850;355:8869)
                                left: 41*fem,
                                top: 13*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 36*fem,
                                    height: 17*fem,
                                    child: Text(
                                      'PRQS',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff4c4c4c),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // Gyd (I390:1013;242:7850;355:8858)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangledpB (I390:1013;242:7850;355:8859)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-V1H.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorm9h (I390:1013;242:7850;355:8861)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-R3D.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // tVD (I390:1013;268:300;268:288)
                                left: 21*fem,
                                top: 5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 18*fem,
                                    height: 36*fem,
                                    child: Text(
                                      '+',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xfffff9f9),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // zHM (I390:1013;242:7850;355:8852)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleM7u (I390:1013;242:7850;355:8853)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-P7u.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectoresh (I390:1013;242:7850;355:8855)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-LXH.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // xNoh (I390:1013;268:301;268:290)
                                left: 20*fem,
                                top: 5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 13*fem,
                                    height: 30*fem,
                                    child: Text(
                                      'x',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 25*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 5*fem,
                  ),
                  Container(
                    // autogroupxqqhEL7 (CJ2yc1yV8pP6drzVNoxqqH)
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogrouprb8tyHh (CJ2yiM8Ghh8yjEqHYARB8T)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // group37Pu (I390:1013;242:7850;355:8905)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 84*fem,
                                    height: 44*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/group-3-F5q.png',
                                      width: 84*fem,
                                      height: 44*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // BuZ (I390:1013;268:299;268:286)
                                left: 23*fem,
                                top: 4*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 11*fem,
                                    height: 36*fem,
                                    child: Text(
                                      ')',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 30*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        Container(
                          // FPd (I390:1013;242:7850;355:8846)
                          width: 84*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangleoR9 (I390:1013;242:7850;355:8847)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 84*fem,
                                  height: 44*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-zVm.png',
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    // vectorX6F (I390:1013;242:7850;355:8849)
                                    child: SizedBox(
                                      width: 84*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-jVR.png',
                                        width: 84*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // fill1duy (I390:1013;268:285)
                                left: 26*fem,
                                top: 12*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 26*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/fill-1.png',
                                      width: 26*fem,
                                      height: 20*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 5*fem,
                        ),
                        TextButton(
                          // actionbutton6Hm (I390:1013;242:7850;355:8910)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 84*fem,
                            height: 44*fem,
                            child: Image.asset(
                              'assets/page-1/images/action-button.png',
                              width: 84*fem,
                              height: 44*fem,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
          );
  }
}